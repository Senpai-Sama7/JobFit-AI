import bcrypt from "bcryptjs"
import jwt from "jsonwebtoken"
import { Database } from "./database"

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"
const JWT_EXPIRES_IN = "7d"

export interface AuthUser {
  id: string
  name: string
  email: string
  subscription: string
}

export class AuthService {
  static async hashPassword(password: string): Promise<string> {
    return bcrypt.hash(password, 12)
  }

  static async comparePassword(password: string, hash: string): Promise<boolean> {
    return bcrypt.compare(password, hash)
  }

  static generateToken(userId: string): string {
    return jwt.sign({ userId }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN })
  }

  static verifyToken(token: string): { userId: string } | null {
    try {
      return jwt.verify(token, JWT_SECRET) as { userId: string }
    } catch {
      return null
    }
  }

  static async signUp(
    name: string,
    email: string,
    password: string,
  ): Promise<{
    user: AuthUser
    token: string
  }> {
    // Check if user already exists
    const existingUser = await Database.getUserByEmail(email)
    if (existingUser) {
      throw new Error("User with this email already exists")
    }

    // Hash password
    const passwordHash = await this.hashPassword(password)

    // Create user
    const user = await Database.createUser(name, email, passwordHash)

    // Generate token
    const token = this.generateToken(user.id)

    // Create session
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days
    await Database.createSession(user.id, token, expiresAt)

    return {
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        subscription: user.subscription,
      },
      token,
    }
  }

  static async signIn(
    email: string,
    password: string,
  ): Promise<{
    user: AuthUser
    token: string
  }> {
    // Get user by email
    const user = await Database.getUserByEmail(email)
    if (!user) {
      throw new Error("Invalid email or password")
    }

    // Verify password
    const isValidPassword = await this.comparePassword(password, user.password_hash)
    if (!isValidPassword) {
      throw new Error("Invalid email or password")
    }

    // Generate token
    const token = this.generateToken(user.id)

    // Create session
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days
    await Database.createSession(user.id, token, expiresAt)

    return {
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        subscription: user.subscription,
      },
      token,
    }
  }

  static async signOut(token: string): Promise<void> {
    await Database.deleteSession(token)
  }

  static async getCurrentUser(token: string): Promise<AuthUser | null> {
    const session = await Database.getSessionByToken(token)
    if (!session) {
      return null
    }

    return {
      id: session.id,
      name: session.name,
      email: session.email,
      subscription: session.subscription,
    }
  }
}
