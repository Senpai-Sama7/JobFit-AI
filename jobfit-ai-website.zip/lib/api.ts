// API utilities for JobFit AI

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3001/api"

export interface ApiResponse<T> {
  success: boolean
  data?: T
  error?: string
  message?: string
}

export interface User {
  id: string
  name: string
  email: string
  createdAt: string
  subscription: "free" | "pro" | "business"
}

export interface Resume {
  id: string
  name: string
  originalFileName: string
  atsScore: number
  status: "processing" | "completed" | "error"
  createdAt: string
  updatedAt: string
  content: {
    personalInfo: {
      name: string
      email: string
      phone: string
      location: string
      linkedin?: string
      website?: string
    }
    summary: string
    experience: Array<{
      title: string
      company: string
      location: string
      startDate: string
      endDate: string
      description: string
    }>
    education: Array<{
      degree: string
      school: string
      location: string
      graduationDate: string
      gpa?: string
    }>
    skills: string[]
  }
}

export interface JobRecommendation {
  id: string
  title: string
  company: string
  location: string
  salary: string
  fitScore: number
  description: string
  requirements: string[]
  postedDate: string
}

class ApiClient {
  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<ApiResponse<T>> {
    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        headers: {
          "Content-Type": "application/json",
          ...options.headers,
        },
        ...options,
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "An error occurred")
      }

      return data
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      }
    }
  }

  // Authentication
  async signIn(email: string, password: string): Promise<ApiResponse<{ user: User; token: string }>> {
    return this.request("/auth/signin", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    })
  }

  async signUp(name: string, email: string, password: string): Promise<ApiResponse<{ user: User; token: string }>> {
    return this.request("/auth/signup", {
      method: "POST",
      body: JSON.stringify({ name, email, password }),
    })
  }

  async signOut(): Promise<ApiResponse<null>> {
    return this.request("/auth/signout", {
      method: "POST",
    })
  }

  // Resume Management
  async uploadResume(file: File): Promise<ApiResponse<Resume>> {
    const formData = new FormData()
    formData.append("resume", file)

    return fetch(`${API_BASE_URL}/resumes/upload`, {
      method: "POST",
      body: formData,
    }).then((res) => res.json())
  }

  async getResumes(): Promise<ApiResponse<Resume[]>> {
    return this.request("/resumes")
  }

  async getResume(id: string): Promise<ApiResponse<Resume>> {
    return this.request(`/resumes/${id}`)
  }

  async updateResume(id: string, content: Partial<Resume["content"]>): Promise<ApiResponse<Resume>> {
    return this.request(`/resumes/${id}`, {
      method: "PUT",
      body: JSON.stringify({ content }),
    })
  }

  async deleteResume(id: string): Promise<ApiResponse<null>> {
    return this.request(`/resumes/${id}`, {
      method: "DELETE",
    })
  }

  async analyzeResume(id: string): Promise<ApiResponse<{ atsScore: number; suggestions: any[] }>> {
    return this.request(`/resumes/${id}/analyze`, {
      method: "POST",
    })
  }

  // Job Recommendations
  async getJobRecommendations(resumeId?: string): Promise<ApiResponse<JobRecommendation[]>> {
    const query = resumeId ? `?resumeId=${resumeId}` : ""
    return this.request(`/jobs/recommendations${query}`)
  }

  // Contact
  async submitContactForm(data: {
    name: string
    email: string
    subject: string
    category: string
    message: string
  }): Promise<ApiResponse<null>> {
    return this.request("/contact", {
      method: "POST",
      body: JSON.stringify(data),
    })
  }
}

export const api = new ApiClient()

// Utility functions
export const getAuthToken = (): string | null => {
  if (typeof window === "undefined") return null
  return localStorage.getItem("auth_token")
}

export const setAuthToken = (token: string): void => {
  if (typeof window === "undefined") return
  localStorage.setItem("auth_token", token)
}

export const removeAuthToken = (): void => {
  if (typeof window === "undefined") return
  localStorage.removeItem("auth_token")
}

export const isAuthenticated = (): boolean => {
  return !!getAuthToken()
}
