import { Database } from "./database"

export interface AdminStats {
  totalUsers: number
  totalResumes: number
  totalAnalyses: number
  recentSignups: number
  activeSubscriptions: number
  revenue: number
}

export interface UserActivity {
  id: string
  name: string
  email: string
  subscription: string
  resumeCount: number
  lastActive: string
  createdAt: string
}

export class AdminService {
  static async getDashboardStats(): Promise<AdminStats> {
    const client = await Database.pool.connect()

    try {
      // Get total users
      const usersResult = await client.query("SELECT COUNT(*) as count FROM users")
      const totalUsers = Number.parseInt(usersResult.rows[0].count)

      // Get recent signups (last 30 days)
      const recentSignupsResult = await client.query(
        "SELECT COUNT(*) as count FROM users WHERE created_at >= NOW() - INTERVAL '30 days'",
      )
      const recentSignups = Number.parseInt(recentSignupsResult.rows[0].count)

      // Get total resumes
      const resumesResult = await client.query("SELECT COUNT(*) as count FROM resumes")
      const totalResumes = Number.parseInt(resumesResult.rows[0].count)

      // Get completed analyses
      const analysesResult = await client.query("SELECT COUNT(*) as count FROM resumes WHERE status = 'completed'")
      const totalAnalyses = Number.parseInt(analysesResult.rows[0].count)

      // Get active subscriptions (non-free)
      const subscriptionsResult = await client.query("SELECT COUNT(*) as count FROM users WHERE subscription != 'free'")
      const activeSubscriptions = Number.parseInt(subscriptionsResult.rows[0].count)

      // Calculate estimated revenue (simplified)
      const revenue = activeSubscriptions * 19 // Assuming average of $19/month

      return {
        totalUsers,
        totalResumes,
        totalAnalyses,
        recentSignups,
        activeSubscriptions,
        revenue,
      }
    } finally {
      client.release()
    }
  }

  static async getUserActivity(limit = 50): Promise<UserActivity[]> {
    const client = await Database.pool.connect()

    try {
      const result = await client.query(
        `
        SELECT 
          u.id,
          u.name,
          u.email,
          u.subscription,
          u.created_at,
          u.updated_at as last_active,
          COUNT(r.id) as resume_count
        FROM users u
        LEFT JOIN resumes r ON u.id = r.user_id
        GROUP BY u.id, u.name, u.email, u.subscription, u.created_at, u.updated_at
        ORDER BY u.updated_at DESC
        LIMIT $1
      `,
        [limit],
      )

      return result.rows.map((row) => ({
        id: row.id,
        name: row.name,
        email: row.email,
        subscription: row.subscription,
        resumeCount: Number.parseInt(row.resume_count),
        lastActive: row.last_active,
        createdAt: row.created_at,
      }))
    } finally {
      client.release()
    }
  }

  static async getContactSubmissions(limit = 50): Promise<any[]> {
    const client = await Database.pool.connect()

    try {
      const result = await client.query(
        `
        SELECT * FROM contact_submissions 
        ORDER BY created_at DESC 
        LIMIT $1
      `,
        [limit],
      )

      return result.rows
    } finally {
      client.release()
    }
  }

  static async updateUserSubscription(userId: string, subscription: string): Promise<void> {
    const client = await Database.pool.connect()

    try {
      await client.query("UPDATE users SET subscription = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2", [
        subscription,
        userId,
      ])
    } finally {
      client.release()
    }
  }

  static async deleteUser(userId: string): Promise<void> {
    const client = await Database.pool.connect()

    try {
      // This will cascade delete resumes, sessions, etc.
      await client.query("DELETE FROM users WHERE id = $1", [userId])
    } finally {
      client.release()
    }
  }

  static async getSystemHealth(): Promise<any> {
    const client = await Database.pool.connect()

    try {
      // Check database connection
      await client.query("SELECT 1")

      // Get database size
      const dbSizeResult = await client.query(`
        SELECT pg_size_pretty(pg_database_size(current_database())) as size
      `)

      // Get recent errors (if you have an errors table)
      const recentErrors = 0 // Placeholder

      return {
        database: {
          status: "healthy",
          size: dbSizeResult.rows[0].size,
        },
        errors: {
          recent: recentErrors,
        },
        uptime: process.uptime(),
      }
    } finally {
      client.release()
    }
  }
}
