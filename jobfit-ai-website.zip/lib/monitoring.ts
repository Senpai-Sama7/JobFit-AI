export interface ErrorReport {
  error: Error
  context?: Record<string, any>
  userId?: string
  timestamp?: Date
}

export class Monitoring {
  static async reportError(report: ErrorReport): Promise<void> {
    try {
      const errorData = {
        message: report.error.message,
        stack: report.error.stack,
        context: report.context,
        userId: report.userId,
        timestamp: report.timestamp || new Date(),
        url: typeof window !== "undefined" ? window.location.href : undefined,
        userAgent: typeof window !== "undefined" ? window.navigator.userAgent : undefined,
      }

      // In production, send to error monitoring service
      console.error("Error Report:", errorData)

      // You could integrate with services like:
      // - Sentry
      // - Bugsnag
      // - Rollbar
      // - LogRocket
    } catch (error) {
      console.error("Error reporting failed:", error)
    }
  }

  static async reportPerformance(metric: string, value: number, context?: Record<string, any>): Promise<void> {
    try {
      const performanceData = {
        metric,
        value,
        context,
        timestamp: new Date(),
      }

      console.log("Performance Metric:", performanceData)

      // In production, send to performance monitoring service
    } catch (error) {
      console.error("Performance reporting failed:", error)
    }
  }
}
