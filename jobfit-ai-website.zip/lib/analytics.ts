export interface AnalyticsEvent {
  event: string
  userId?: string
  properties?: Record<string, any>
  timestamp?: Date
}

export class Analytics {
  static async track(event: AnalyticsEvent): Promise<void> {
    try {
      // In production, you would send this to your analytics service
      // For now, we'll just log it
      console.log("Analytics Event:", {
        ...event,
        timestamp: event.timestamp || new Date(),
      })

      // You could integrate with services like:
      // - Google Analytics
      // - Mixpanel
      // - Amplitude
      // - PostHog
      // - Custom analytics service
    } catch (error) {
      console.error("Analytics tracking failed:", error)
    }
  }

  static async trackResumeUpload(userId: string, fileType: string): Promise<void> {
    await this.track({
      event: "resume_uploaded",
      userId,
      properties: { fileType },
    })
  }

  static async trackResumeAnalysis(userId: string, atsScore: number): Promise<void> {
    await this.track({
      event: "resume_analyzed",
      userId,
      properties: { atsScore },
    })
  }

  static async trackSubscription(userId: string, plan: string): Promise<void> {
    await this.track({
      event: "subscription_created",
      userId,
      properties: { plan },
    })
  }

  static async trackJobRecommendation(userId: string, jobCount: number): Promise<void> {
    await this.track({
      event: "job_recommendations_generated",
      userId,
      properties: { jobCount },
    })
  }
}
