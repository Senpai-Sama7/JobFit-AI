import nodemailer from "nodemailer"

const transporter = nodemailer.createTransporter({
  host: process.env.SMTP_HOST || "smtp.gmail.com",
  port: Number.parseInt(process.env.SMTP_PORT || "587"),
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
})

export interface EmailTemplate {
  to: string
  subject: string
  html: string
  text?: string
}

export class EmailService {
  static async sendEmail(template: EmailTemplate): Promise<void> {
    try {
      await transporter.sendMail({
        from: `"JobFit AI" <${process.env.SMTP_FROM || process.env.SMTP_USER}>`,
        ...template,
      })
    } catch (error) {
      console.error("Failed to send email:", error)
      throw new Error("Failed to send email")
    }
  }

  static async sendWelcomeEmail(email: string, name: string): Promise<void> {
    const template: EmailTemplate = {
      to: email,
      subject: "Welcome to JobFit AI! 🚀",
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Welcome to JobFit AI</title>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #3b82f6, #8b5cf6); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: white; padding: 30px; border-radius: 0 0 10px 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
            .button { display: inline-block; background: #3b82f6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 20px 0; }
            .features { background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0; }
            .feature { margin: 10px 0; }
            .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Welcome to JobFit AI! 🎉</h1>
              <p>Your AI-powered career companion</p>
            </div>
            <div class="content">
              <h2>Hi ${name}!</h2>
              <p>Thank you for joining JobFit AI! We're excited to help you land your dream job with our AI-powered resume optimization platform.</p>
              
              <div class="features">
                <h3>🚀 What you can do now:</h3>
                <div class="feature">✅ Upload and analyze your resume</div>
                <div class="feature">✅ Get instant ATS compatibility scores</div>
                <div class="feature">✅ Receive personalized improvement suggestions</div>
                <div class="feature">✅ Discover job opportunities that match your skills</div>
              </div>

              <p>Ready to get started? Upload your first resume and see how our AI can help optimize it for better job search results.</p>

              <a href="${process.env.NEXT_PUBLIC_APP_URL}/dashboard" class="button">Go to Dashboard</a>

              <p>If you have any questions, our support team is here to help. Just reply to this email!</p>

              <p>Best regards,<br>The JobFit AI Team</p>
            </div>
            <div class="footer">
              <p>JobFit AI - Empowering your career with AI</p>
              <p>If you didn't create this account, please ignore this email.</p>
            </div>
          </div>
        </body>
        </html>
      `,
      text: `
        Welcome to JobFit AI!

        Hi ${name}!

        Thank you for joining JobFit AI! We're excited to help you land your dream job with our AI-powered resume optimization platform.

        What you can do now:
        - Upload and analyze your resume
        - Get instant ATS compatibility scores
        - Receive personalized improvement suggestions
        - Discover job opportunities that match your skills

        Get started: ${process.env.NEXT_PUBLIC_APP_URL}/dashboard

        Best regards,
        The JobFit AI Team
      `,
    }

    await this.sendEmail(template)
  }

  static async sendResumeAnalysisComplete(
    email: string,
    name: string,
    resumeName: string,
    atsScore: number,
  ): Promise<void> {
    const template: EmailTemplate = {
      to: email,
      subject: `Your resume analysis is complete! Score: ${atsScore}%`,
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Resume Analysis Complete</title>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #3b82f6, #8b5cf6); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: white; padding: 30px; border-radius: 0 0 10px 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
            .score { font-size: 48px; font-weight: bold; text-align: center; margin: 20px 0; }
            .score.excellent { color: #10b981; }
            .score.good { color: #f59e0b; }
            .score.needs-work { color: #ef4444; }
            .button { display: inline-block; background: #3b82f6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 20px 0; }
            .tips { background: #f0f9ff; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #3b82f6; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Analysis Complete! 📊</h1>
              <p>Your resume has been analyzed by our AI</p>
            </div>
            <div class="content">
              <h2>Hi ${name}!</h2>
              <p>Great news! We've finished analyzing your resume "<strong>${resumeName}</strong>" and have some insights for you.</p>
              
              <div class="score ${atsScore >= 80 ? "excellent" : atsScore >= 60 ? "good" : "needs-work"}">
                ${atsScore}%
              </div>
              <p style="text-align: center; font-size: 18px; margin-bottom: 30px;">
                <strong>ATS Compatibility Score</strong>
              </p>

              <div class="tips">
                <h3>💡 What this means:</h3>
                ${
                  atsScore >= 80
                    ? "<p>Excellent! Your resume is well-optimized for ATS systems and should perform well in automated screenings.</p>"
                    : atsScore >= 60
                      ? "<p>Good start! Your resume has solid fundamentals but could benefit from some optimization to improve ATS compatibility.</p>"
                      : "<p>There's room for improvement. Our AI has identified several areas where you can enhance your resume's ATS compatibility.</p>"
                }
              </div>

              <p>View your detailed analysis, personalized suggestions, and job recommendations in your dashboard.</p>

              <a href="${process.env.NEXT_PUBLIC_APP_URL}/dashboard" class="button">View Full Analysis</a>

              <p>Keep optimizing and you'll be landing interviews in no time!</p>

              <p>Best regards,<br>The JobFit AI Team</p>
            </div>
          </div>
        </body>
        </html>
      `,
    }

    await this.sendEmail(template)
  }

  static async sendPasswordReset(email: string, resetToken: string): Promise<void> {
    const resetUrl = `${process.env.NEXT_PUBLIC_APP_URL}/auth/reset-password?token=${resetToken}`

    const template: EmailTemplate = {
      to: email,
      subject: "Reset your JobFit AI password",
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Reset Your Password</title>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .content { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
            .button { display: inline-block; background: #3b82f6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 20px 0; }
            .warning { background: #fef3c7; padding: 15px; border-radius: 6px; border-left: 4px solid #f59e0b; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="content">
              <h2>Reset Your Password</h2>
              <p>You requested to reset your password for your JobFit AI account.</p>
              
              <p>Click the button below to reset your password:</p>
              
              <a href="${resetUrl}" class="button">Reset Password</a>
              
              <div class="warning">
                <strong>⚠️ Security Notice:</strong>
                <p>This link will expire in 1 hour for security reasons. If you didn't request this password reset, please ignore this email.</p>
              </div>
              
              <p>If the button doesn't work, copy and paste this link into your browser:</p>
              <p style="word-break: break-all; color: #666;">${resetUrl}</p>
              
              <p>Best regards,<br>The JobFit AI Team</p>
            </div>
          </div>
        </body>
        </html>
      `,
    }

    await this.sendEmail(template)
  }

  static async sendContactFormNotification(submission: any): Promise<void> {
    const template: EmailTemplate = {
      to: process.env.ADMIN_EMAIL || "admin@jobfit.ai",
      subject: `New Contact Form Submission: ${submission.subject}`,
      html: `
        <h2>New Contact Form Submission</h2>
        <p><strong>Name:</strong> ${submission.name}</p>
        <p><strong>Email:</strong> ${submission.email}</p>
        <p><strong>Category:</strong> ${submission.category}</p>
        <p><strong>Subject:</strong> ${submission.subject}</p>
        <p><strong>Message:</strong></p>
        <div style="background: #f5f5f5; padding: 15px; border-radius: 5px;">
          ${submission.message.replace(/\n/g, "<br>")}
        </div>
        <p><strong>Submitted:</strong> ${new Date().toLocaleString()}</p>
      `,
    }

    await this.sendEmail(template)
  }
}
