import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export interface ResumeAnalysis {
  atsScore: number
  suggestions: Array<{
    type: "improvement" | "warning" | "success"
    category: string
    title: string
    description: string
    impact: "high" | "medium" | "low" | "positive"
  }>
  keywords: string[]
  strengths: string[]
  weaknesses: string[]
  industryMatch: number
}

export interface JobMatch {
  title: string
  company: string
  location: string
  salary: string
  fitScore: number
  description: string
  requirements: string[]
  matchReasons: string[]
}

export class AIService {
  private static model = openai("gpt-4o")

  static async analyzeResume(resumeContent: string, targetIndustry?: string): Promise<ResumeAnalysis> {
    try {
      const prompt = `
        Analyze the following resume and provide a comprehensive assessment:

        Resume Content:
        ${resumeContent}

        ${targetIndustry ? `Target Industry: ${targetIndustry}` : ""}

        Please provide:
        1. ATS Score (0-100) based on formatting, keywords, and structure
        2. Specific suggestions for improvement
        3. Relevant keywords found and missing
        4. Strengths and weaknesses
        5. Industry match score if target industry provided

        Return the analysis in JSON format with the following structure:
        {
          "atsScore": number,
          "suggestions": [
            {
              "type": "improvement|warning|success",
              "category": "string",
              "title": "string",
              "description": "string",
              "impact": "high|medium|low|positive"
            }
          ],
          "keywords": ["string"],
          "strengths": ["string"],
          "weaknesses": ["string"],
          "industryMatch": number
        }
      `

      const { text } = await generateText({
        model: this.model,
        prompt,
        temperature: 0.3,
      })

      // Parse the JSON response
      const analysis = JSON.parse(text) as ResumeAnalysis

      // Validate and sanitize the response
      return {
        atsScore: Math.max(0, Math.min(100, analysis.atsScore || 0)),
        suggestions: analysis.suggestions || [],
        keywords: analysis.keywords || [],
        strengths: analysis.strengths || [],
        weaknesses: analysis.weaknesses || [],
        industryMatch: Math.max(0, Math.min(100, analysis.industryMatch || 0)),
      }
    } catch (error) {
      console.error("Error analyzing resume:", error)

      // Return fallback analysis
      return {
        atsScore: 65,
        suggestions: [
          {
            type: "improvement",
            category: "Analysis",
            title: "Analysis temporarily unavailable",
            description: "Our AI analysis service is currently unavailable. Please try again later.",
            impact: "medium",
          },
        ],
        keywords: [],
        strengths: ["Professional experience"],
        weaknesses: ["Analysis pending"],
        industryMatch: 70,
      }
    }
  }

  static async generateJobRecommendations(
    resumeContent: string,
    userSkills: string[],
    location?: string,
  ): Promise<JobMatch[]> {
    try {
      const prompt = `
        Based on the following resume and skills, recommend relevant job opportunities:

        Resume Content:
        ${resumeContent}

        Skills: ${userSkills.join(", ")}
        ${location ? `Preferred Location: ${location}` : ""}

        Generate 5 realistic job recommendations with:
        1. Job title and company (use real company names when possible)
        2. Location and salary range
        3. Fit score (0-100) based on resume match
        4. Job description
        5. Key requirements
        6. Reasons why this person would be a good fit

        Return as JSON array:
        [
          {
            "title": "string",
            "company": "string",
            "location": "string",
            "salary": "string",
            "fitScore": number,
            "description": "string",
            "requirements": ["string"],
            "matchReasons": ["string"]
          }
        ]
      `

      const { text } = await generateText({
        model: this.model,
        prompt,
        temperature: 0.4,
      })

      const recommendations = JSON.parse(text) as JobMatch[]

      // Validate and sanitize recommendations
      return recommendations.map((job) => ({
        ...job,
        fitScore: Math.max(0, Math.min(100, job.fitScore || 0)),
        requirements: job.requirements || [],
        matchReasons: job.matchReasons || [],
      }))
    } catch (error) {
      console.error("Error generating job recommendations:", error)

      // Return fallback recommendations
      return [
        {
          title: "Software Engineer",
          company: "Tech Company",
          location: "San Francisco, CA",
          salary: "$120k - $180k",
          fitScore: 85,
          description: "Join our team to build innovative software solutions.",
          requirements: ["Programming experience", "Problem-solving skills"],
          matchReasons: ["Strong technical background", "Relevant experience"],
        },
      ]
    }
  }

  static async optimizeResumeForJob(
    resumeContent: string,
    jobDescription: string,
  ): Promise<{
    optimizedContent: string
    changes: string[]
    improvementScore: number
  }> {
    try {
      const prompt = `
        Optimize the following resume for this specific job posting:

        Current Resume:
        ${resumeContent}

        Job Description:
        ${jobDescription}

        Please:
        1. Suggest specific changes to better match the job requirements
        2. Identify keywords to add or emphasize
        3. Recommend content restructuring if needed
        4. Provide an improvement score (0-100)

        Return as JSON:
        {
          "optimizedContent": "string",
          "changes": ["string"],
          "improvementScore": number
        }
      `

      const { text } = await generateText({
        model: this.model,
        prompt,
        temperature: 0.3,
      })

      const optimization = JSON.parse(text)

      return {
        optimizedContent: optimization.optimizedContent || resumeContent,
        changes: optimization.changes || [],
        improvementScore: Math.max(0, Math.min(100, optimization.improvementScore || 0)),
      }
    } catch (error) {
      console.error("Error optimizing resume:", error)

      return {
        optimizedContent: resumeContent,
        changes: ["Optimization service temporarily unavailable"],
        improvementScore: 0,
      }
    }
  }

  static async parseResumeContent(fileContent: string, fileType: string): Promise<any> {
    try {
      const prompt = `
        Parse the following resume content and extract structured information:

        File Type: ${fileType}
        Content:
        ${fileContent}

        Extract and return in JSON format:
        {
          "personalInfo": {
            "name": "string",
            "email": "string",
            "phone": "string",
            "location": "string",
            "linkedin": "string",
            "website": "string"
          },
          "summary": "string",
          "experience": [
            {
              "title": "string",
              "company": "string",
              "location": "string",
              "startDate": "string",
              "endDate": "string",
              "description": "string"
            }
          ],
          "education": [
            {
              "degree": "string",
              "school": "string",
              "location": "string",
              "graduationDate": "string",
              "gpa": "string"
            }
          ],
          "skills": ["string"]
        }
      `

      const { text } = await generateText({
        model: this.model,
        prompt,
        temperature: 0.1,
      })

      return JSON.parse(text)
    } catch (error) {
      console.error("Error parsing resume:", error)

      // Return basic structure
      return {
        personalInfo: {
          name: "Name not found",
          email: "",
          phone: "",
          location: "",
          linkedin: "",
          website: "",
        },
        summary: "Summary not available",
        experience: [],
        education: [],
        skills: [],
      }
    }
  }
}
