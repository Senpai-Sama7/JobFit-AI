import { Pool } from "pg"

// Database connection
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
})

// Database schema initialization
export const initializeDatabase = async () => {
  const client = await pool.connect()

  try {
    // Users table
    await client.query(`
      CREATE TABLE IF NOT EXISTS users (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        subscription VARCHAR(50) DEFAULT 'free',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `)

    // Resumes table
    await client.query(`
      CREATE TABLE IF NOT EXISTS resumes (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        user_id UUID REFERENCES users(id) ON DELETE CASCADE,
        name VARCHAR(255) NOT NULL,
        original_filename VARCHAR(255) NOT NULL,
        file_path VARCHAR(500),
        ats_score INTEGER DEFAULT 0,
        status VARCHAR(50) DEFAULT 'processing',
        content JSONB,
        analysis_results JSONB,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `)

    // Sessions table
    await client.query(`
      CREATE TABLE IF NOT EXISTS sessions (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        user_id UUID REFERENCES users(id) ON DELETE CASCADE,
        token VARCHAR(255) UNIQUE NOT NULL,
        expires_at TIMESTAMP NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `)

    // Job recommendations table
    await client.query(`
      CREATE TABLE IF NOT EXISTS job_recommendations (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        user_id UUID REFERENCES users(id) ON DELETE CASCADE,
        resume_id UUID REFERENCES resumes(id) ON DELETE CASCADE,
        title VARCHAR(255) NOT NULL,
        company VARCHAR(255) NOT NULL,
        location VARCHAR(255),
        salary VARCHAR(100),
        fit_score INTEGER,
        description TEXT,
        requirements JSONB,
        posted_date TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `)

    // Contact submissions table
    await client.query(`
      CREATE TABLE IF NOT EXISTS contact_submissions (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        subject VARCHAR(255) NOT NULL,
        category VARCHAR(100),
        message TEXT NOT NULL,
        status VARCHAR(50) DEFAULT 'new',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `)

    // Create indexes for better performance
    await client.query(`
      CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
      CREATE INDEX IF NOT EXISTS idx_resumes_user_id ON resumes(user_id);
      CREATE INDEX IF NOT EXISTS idx_sessions_token ON sessions(token);
      CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON sessions(user_id);
      CREATE INDEX IF NOT EXISTS idx_job_recommendations_user_id ON job_recommendations(user_id);
    `)

    console.log("Database initialized successfully")
  } catch (error) {
    console.error("Error initializing database:", error)
    throw error
  } finally {
    client.release()
  }
}

// Database query helpers
export class Database {
  // User operations
  static async createUser(name: string, email: string, passwordHash: string) {
    const client = await pool.connect()
    try {
      const result = await client.query(
        "INSERT INTO users (name, email, password_hash) VALUES ($1, $2, $3) RETURNING *",
        [name, email, passwordHash],
      )
      return result.rows[0]
    } finally {
      client.release()
    }
  }

  static async getUserByEmail(email: string) {
    const client = await pool.connect()
    try {
      const result = await client.query("SELECT * FROM users WHERE email = $1", [email])
      return result.rows[0]
    } finally {
      client.release()
    }
  }

  static async getUserById(id: string) {
    const client = await pool.connect()
    try {
      const result = await client.query("SELECT * FROM users WHERE id = $1", [id])
      return result.rows[0]
    } finally {
      client.release()
    }
  }

  // Session operations
  static async createSession(userId: string, token: string, expiresAt: Date) {
    const client = await pool.connect()
    try {
      const result = await client.query(
        "INSERT INTO sessions (user_id, token, expires_at) VALUES ($1, $2, $3) RETURNING *",
        [userId, token, expiresAt],
      )
      return result.rows[0]
    } finally {
      client.release()
    }
  }

  static async getSessionByToken(token: string) {
    const client = await pool.connect()
    try {
      const result = await client.query(
        "SELECT s.*, u.* FROM sessions s JOIN users u ON s.user_id = u.id WHERE s.token = $1 AND s.expires_at > NOW()",
        [token],
      )
      return result.rows[0]
    } finally {
      client.release()
    }
  }

  static async deleteSession(token: string) {
    const client = await pool.connect()
    try {
      await client.query("DELETE FROM sessions WHERE token = $1", [token])
    } finally {
      client.release()
    }
  }

  // Resume operations
  static async createResume(userId: string, name: string, originalFilename: string, filePath: string) {
    const client = await pool.connect()
    try {
      const result = await client.query(
        "INSERT INTO resumes (user_id, name, original_filename, file_path) VALUES ($1, $2, $3, $4) RETURNING *",
        [userId, name, originalFilename, filePath],
      )
      return result.rows[0]
    } finally {
      client.release()
    }
  }

  static async getResumesByUserId(userId: string) {
    const client = await pool.connect()
    try {
      const result = await client.query("SELECT * FROM resumes WHERE user_id = $1 ORDER BY created_at DESC", [userId])
      return result.rows
    } finally {
      client.release()
    }
  }

  static async getResumeById(id: string, userId: string) {
    const client = await pool.connect()
    try {
      const result = await client.query("SELECT * FROM resumes WHERE id = $1 AND user_id = $2", [id, userId])
      return result.rows[0]
    } finally {
      client.release()
    }
  }

  static async updateResume(id: string, userId: string, updates: any) {
    const client = await pool.connect()
    try {
      const setClause = Object.keys(updates)
        .map((key, index) => `${key} = $${index + 3}`)
        .join(", ")

      const values = [id, userId, ...Object.values(updates)]

      const result = await client.query(
        `UPDATE resumes SET ${setClause}, updated_at = CURRENT_TIMESTAMP WHERE id = $1 AND user_id = $2 RETURNING *`,
        values,
      )
      return result.rows[0]
    } finally {
      client.release()
    }
  }

  static async deleteResume(id: string, userId: string) {
    const client = await pool.connect()
    try {
      await client.query("DELETE FROM resumes WHERE id = $1 AND user_id = $2", [id, userId])
    } finally {
      client.release()
    }
  }

  // Contact submissions
  static async createContactSubmission(data: any) {
    const client = await pool.connect()
    try {
      const result = await client.query(
        "INSERT INTO contact_submissions (name, email, subject, category, message) VALUES ($1, $2, $3, $4, $5) RETURNING *",
        [data.name, data.email, data.subject, data.category, data.message],
      )
      return result.rows[0]
    } finally {
      client.release()
    }
  }
}

export default pool
