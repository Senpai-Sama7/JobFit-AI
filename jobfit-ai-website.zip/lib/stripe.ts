import Stripe from "stripe"

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2024-06-20",
})

export interface SubscriptionPlan {
  id: string
  name: string
  price: number
  interval: "month" | "year"
  features: string[]
  stripePriceId: string
}

export const SUBSCRIPTION_PLANS: SubscriptionPlan[] = [
  {
    id: "free",
    name: "Free",
    price: 0,
    interval: "month",
    features: ["1 resume upload per month", "Basic ATS scoring", "Standard templates"],
    stripePriceId: "",
  },
  {
    id: "pro",
    name: "Pro",
    price: 19,
    interval: "month",
    features: [
      "Unlimited resume uploads",
      "Advanced ATS scoring",
      "AI role recommendations",
      "Custom tailoring",
      "Premium templates",
      "Priority support",
    ],
    stripePriceId: process.env.STRIPE_PRO_PRICE_ID!,
  },
  {
    id: "business",
    name: "Business",
    price: 49,
    interval: "month",
    features: [
      "Everything in Pro",
      "Bulk processing",
      "Team collaboration",
      "API access",
      "Analytics dashboard",
      "Dedicated support",
    ],
    stripePriceId: process.env.STRIPE_BUSINESS_PRICE_ID!,
  },
]

export class StripeService {
  static async createCustomer(email: string, name: string): Promise<Stripe.Customer> {
    return await stripe.customers.create({
      email,
      name,
    })
  }

  static async createSubscription(customerId: string, priceId: string): Promise<Stripe.Subscription> {
    return await stripe.subscriptions.create({
      customer: customerId,
      items: [{ price: priceId }],
      payment_behavior: "default_incomplete",
      payment_settings: { save_default_payment_method: "on_subscription" },
      expand: ["latest_invoice.payment_intent"],
    })
  }

  static async createPaymentIntent(amount: number, customerId: string): Promise<Stripe.PaymentIntent> {
    return await stripe.paymentIntents.create({
      amount: amount * 100, // Convert to cents
      currency: "usd",
      customer: customerId,
      automatic_payment_methods: { enabled: true },
    })
  }

  static async cancelSubscription(subscriptionId: string): Promise<Stripe.Subscription> {
    return await stripe.subscriptions.cancel(subscriptionId)
  }

  static async updateSubscription(subscriptionId: string, priceId: string): Promise<Stripe.Subscription> {
    const subscription = await stripe.subscriptions.retrieve(subscriptionId)
    return await stripe.subscriptions.update(subscriptionId, {
      items: [
        {
          id: subscription.items.data[0].id,
          price: priceId,
        },
      ],
    })
  }

  static async constructWebhookEvent(body: string, signature: string): Promise<Stripe.Event> {
    return stripe.webhooks.constructEvent(body, signature, process.env.STRIPE_WEBHOOK_SECRET!)
  }

  static async getCustomerPortalUrl(customerId: string, returnUrl: string): Promise<string> {
    const session = await stripe.billingPortal.sessions.create({
      customer: customerId,
      return_url: returnUrl,
    })
    return session.url
  }
}
