import express from "express"
import cors from "cors"
import multer from "multer"
import path from "path"
import fs from "fs"
import { fileURLToPath } from "url"
import { initializeDatabase, Database } from "../lib/database.js"
import { AuthService } from "../lib/auth.js"
import { FileProcessor } from "../lib/file-processor.js"

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const app = express()
const PORT = process.env.PORT || 3001

// Initialize database
initializeDatabase().catch(console.error)

// Middleware
app.use(cors())
app.use(express.json())
app.use(express.static("public"))

// File upload configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, "../uploads")
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true })
    }
    cb(null, uploadDir)
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9)
    cb(null, file.fieldname + "-" + uniqueSuffix + path.extname(file.originalname))
  },
})

const upload = multer({
  storage,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = [".pdf", ".docx", ".txt", ".md", ".rtf", ".odt"]
    const fileExt = path.extname(file.originalname).toLowerCase()

    if (allowedTypes.includes(fileExt)) {
      cb(null, true)
    } else {
      cb(new Error("Invalid file type. Only PDF, DOCX, TXT, MD, RTF, and ODT files are allowed."))
    }
  },
})

// Authentication middleware
const authenticateToken = async (req: any, res: any, next: any) => {
  const authHeader = req.headers["authorization"]
  const token = authHeader && authHeader.split(" ")[1]

  if (!token) {
    return res.status(401).json({ success: false, error: "Access token required" })
  }

  try {
    const user = await AuthService.getCurrentUser(token)
    if (!user) {
      return res.status(403).json({ success: false, error: "Invalid token" })
    }

    req.user = user
    next()
  } catch (error) {
    return res.status(403).json({ success: false, error: "Invalid token" })
  }
}

// Routes

// Health check
app.get("/api/health", (req, res) => {
  res.json({ success: true, message: "Server is running" })
})

// Authentication routes
app.post("/api/auth/signup", async (req, res) => {
  try {
    const { name, email, password } = req.body

    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        error: "Name, email, and password are required",
      })
    }

    const result = await AuthService.signUp(name, email, password)

    res.json({
      success: true,
      data: result,
    })
  } catch (error: any) {
    res.status(400).json({
      success: false,
      error: error.message,
    })
  }
})

app.post("/api/auth/signin", async (req, res) => {
  try {
    const { email, password } = req.body

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        error: "Email and password are required",
      })
    }

    const result = await AuthService.signIn(email, password)

    res.json({
      success: true,
      data: result,
    })
  } catch (error: any) {
    res.status(401).json({
      success: false,
      error: error.message,
    })
  }
})

app.post("/api/auth/signout", authenticateToken, async (req, res) => {
  const authHeader = req.headers["authorization"]
  const token = authHeader && authHeader.split(" ")[1]

  if (token) {
    await AuthService.signOut(token)
  }

  res.json({ success: true, message: "Signed out successfully" })
})

// Resume routes
app.post("/api/resumes/upload", authenticateToken, upload.single("resume"), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        error: "No file uploaded",
      })
    }

    // Create resume record in database
    const resume = await Database.createResume(
      req.user.id,
      req.file.originalname.replace(/\.[^/.]+$/, ""),
      req.file.originalname,
      req.file.path,
    )

    // Process file in background
    try {
      const processedData = await FileProcessor.processResumeFile(req.file.path, req.file.originalname)

      // Update resume with processed content and analysis
      await Database.updateResume(resume.id, req.user.id, {
        content: processedData.content,
        analysis_results: processedData.analysis,
        ats_score: processedData.analysis.atsScore,
        status: "completed",
      })

      // Generate job recommendations
      const recommendations = await FileProcessor.generateJobRecommendations(req.user.id, processedData)

      // Store recommendations (you could add this to the database)
      console.log("Generated recommendations:", recommendations)
    } catch (processingError) {
      console.error("Error processing file:", processingError)

      // Update status to error
      await Database.updateResume(resume.id, req.user.id, {
        status: "error",
      })
    }

    res.json({
      success: true,
      data: resume,
    })
  } catch (error) {
    console.error("Upload error:", error)
    res.status(500).json({
      success: false,
      error: "Failed to upload resume",
    })
  }
})

app.get("/api/resumes", authenticateToken, async (req, res) => {
  try {
    const resumes = await Database.getResumesByUserId(req.user.id)
    res.json({
      success: true,
      data: resumes,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to fetch resumes",
    })
  }
})

app.get("/api/resumes/:id", authenticateToken, async (req, res) => {
  try {
    const resume = await Database.getResumeById(req.params.id, req.user.id)

    if (!resume) {
      return res.status(404).json({
        success: false,
        error: "Resume not found",
      })
    }

    res.json({
      success: true,
      data: resume,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to fetch resume",
    })
  }
})

app.put("/api/resumes/:id", authenticateToken, async (req, res) => {
  try {
    const resume = await Database.updateResume(req.params.id, req.user.id, req.body)

    if (!resume) {
      return res.status(404).json({
        success: false,
        error: "Resume not found",
      })
    }

    res.json({
      success: true,
      data: resume,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to update resume",
    })
  }
})

app.delete("/api/resumes/:id", authenticateToken, async (req, res) => {
  try {
    const resume = await Database.getResumeById(req.params.id, req.user.id)

    if (!resume) {
      return res.status(404).json({
        success: false,
        error: "Resume not found",
      })
    }

    // Delete file from filesystem
    if (resume.file_path && fs.existsSync(resume.file_path)) {
      fs.unlinkSync(resume.file_path)
    }

    await Database.deleteResume(req.params.id, req.user.id)

    res.json({
      success: true,
      message: "Resume deleted successfully",
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to delete resume",
    })
  }
})

app.post("/api/resumes/:id/analyze", authenticateToken, async (req, res) => {
  try {
    const resume = await Database.getResumeById(req.params.id, req.user.id)

    if (!resume) {
      return res.status(404).json({
        success: false,
        error: "Resume not found",
      })
    }

    // Return existing analysis or trigger new analysis
    if (resume.analysis_results) {
      res.json({
        success: true,
        data: {
          atsScore: resume.ats_score,
          suggestions: resume.analysis_results.suggestions || [],
        },
      })
    } else {
      res.json({
        success: true,
        data: {
          atsScore: 0,
          suggestions: [
            {
              type: "warning",
              category: "Analysis",
              title: "Analysis in progress",
              description: "Your resume is being analyzed. Please check back in a few moments.",
              impact: "medium",
            },
          ],
        },
      })
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to analyze resume",
    })
  }
})

// Job recommendations
app.get("/api/jobs/recommendations", authenticateToken, async (req, res) => {
  try {
    // In a real implementation, you would fetch from database
    // For now, return mock data
    const mockJobs = [
      {
        id: "1",
        title: "Senior Software Engineer",
        company: "Google",
        location: "Mountain View, CA",
        salary: "$180k - $250k",
        fitScore: 95,
        description: "Join our team to build scalable systems...",
        requirements: ["5+ years experience", "React", "Node.js"],
        postedDate: new Date().toISOString(),
      },
      {
        id: "2",
        title: "Full Stack Developer",
        company: "Meta",
        location: "Menlo Park, CA",
        salary: "$160k - $220k",
        fitScore: 88,
        description: "Work on cutting-edge social platforms...",
        requirements: ["3+ years experience", "JavaScript", "Python"],
        postedDate: new Date().toISOString(),
      },
    ]

    res.json({
      success: true,
      data: mockJobs,
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to fetch job recommendations",
    })
  }
})

// Contact form
app.post("/api/contact", async (req, res) => {
  try {
    const { name, email, subject, category, message } = req.body

    if (!name || !email || !subject || !message) {
      return res.status(400).json({
        success: false,
        error: "All fields are required",
      })
    }

    // Save to database
    await Database.createContactSubmission({ name, email, subject, category, message })

    res.json({
      success: true,
      message: "Thank you for your message. We will get back to you soon!",
    })
  } catch (error) {
    res.status(500).json({
      success: false,
      error: "Failed to submit contact form",
    })
  }
})

// Error handling middleware
app.use((error: any, req: any, res: any, next: any) => {
  if (error instanceof multer.MulterError) {
    if (error.code === "LIMIT_FILE_SIZE") {
      return res.status(400).json({
        success: false,
        error: "File size too large. Maximum size is 10MB.",
      })
    }
  }

  res.status(500).json({
    success: false,
    error: error.message || "Internal server error",
  })
})

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})
