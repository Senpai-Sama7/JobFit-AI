import { Database } from "../lib/database.js"
import { AuthService } from "../lib/auth.js"

async function seedData() {
  try {
    console.log("Seeding database with sample data...")

    // Create admin user
    const adminUser = await AuthService.signUp("Admin User", "admin@jobfit.ai", "admin123")
    console.log("Created admin user:", adminUser.user.email)

    // Update admin subscription
    await Database.updateUser(adminUser.user.id, { subscription: "business" })

    // Create sample users
    const users = [
      { name: "John Doe", email: "john@example.com", subscription: "pro" },
      { name: "Jane Smith", email: "jane@example.com", subscription: "free" },
      { name: "Bob Johnson", email: "bob@example.com", subscription: "pro" },
    ]

    for (const userData of users) {
      try {
        const user = await AuthService.signUp(userData.name, userData.email, "password123")
        await Database.updateUser(user.user.id, { subscription: userData.subscription })
        console.log(`Created user: ${userData.email}`)
      } catch (error) {
        console.log(`User ${userData.email} might already exist`)
      }
    }

    console.log("Database seeding completed!")
    process.exit(0)
  } catch (error) {
    console.error("Database seeding failed:", error)
    process.exit(1)
  }
}

seedData()
