"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Shield, Zap, Lock, Eye, Database, UserCheck, FileText, Globe } from "lucide-react"
import Link from "next/link"
import { ThemeToggle } from "@/components/theme-toggle"

export default function PrivacyPage() {
  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className="glass-card border-b border-white/10 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold">JobFit AI</span>
          </Link>
          <div className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-muted-foreground hover:text-foreground transition-colors">
              Home
            </Link>
            <Link href="/pricing" className="text-muted-foreground hover:text-foreground transition-colors">
              Pricing
            </Link>
            <Link href="/faq" className="text-muted-foreground hover:text-foreground transition-colors">
              FAQ
            </Link>
            <ThemeToggle />
            <Button variant="outline" className="glass-button bg-transparent">
              Sign In
            </Button>
            <Button className="bg-blue-600 hover:bg-blue-700">Get Started</Button>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <Badge className="mb-6 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
            <Shield className="w-4 h-4 mr-1" />
            Privacy Policy
          </Badge>
          <h1 className="text-5xl font-bold mb-6">Your Privacy Matters</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            We're committed to protecting your personal information and being transparent about how we collect, use, and
            share your data.
          </p>
          <p className="text-sm text-muted-foreground mt-4">Last updated: December 7, 2024</p>
        </div>

        {/* Privacy Overview */}
        <div className="grid md:grid-cols-3 gap-6 mb-16">
          <Card className="glass-card text-center p-6">
            <CardContent className="p-0">
              <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-blue-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Lock className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-bold mb-2">Secure by Design</h3>
              <p className="text-muted-foreground text-sm">
                Enterprise-grade encryption and security measures protect your data
              </p>
            </CardContent>
          </Card>

          <Card className="glass-card text-center p-6">
            <CardContent className="p-0">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Eye className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-bold mb-2">Full Transparency</h3>
              <p className="text-muted-foreground text-sm">
                Clear information about what data we collect and how we use it
              </p>
            </CardContent>
          </Card>

          <Card className="glass-card text-center p-6">
            <CardContent className="p-0">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                <UserCheck className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-bold mb-2">Your Control</h3>
              <p className="text-muted-foreground text-sm">
                You own your data and can delete it or export it at any time
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Privacy Policy Content */}
        <div className="max-w-4xl mx-auto space-y-12">
          {/* Information We Collect */}
          <Card className="glass-card">
            <CardContent className="p-8">
              <div className="flex items-center space-x-3 mb-6">
                <Database className="w-6 h-6 text-blue-500" />
                <h2 className="text-2xl font-bold">Information We Collect</h2>
              </div>

              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-3">Personal Information</h3>
                  <ul className="space-y-2 text-muted-foreground">
                    <li>• Name, email address, and contact information</li>
                    <li>• Account credentials and authentication data</li>
                    <li>• Profile information and preferences</li>
                    <li>• Payment and billing information (processed securely through Stripe)</li>
                  </ul>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3">Resume and Career Data</h3>
                  <ul className="space-y-2 text-muted-foreground">
                    <li>• Resume content, including work experience, education, and skills</li>
                    <li>• Job preferences and career goals</li>
                    <li>• Application history and job search activity</li>
                    <li>• AI-generated insights and recommendations</li>
                  </ul>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3">Usage Information</h3>
                  <ul className="space-y-2 text-muted-foreground">
                    <li>• How you interact with our platform and features</li>
                    <li>• Device information, IP address, and browser type</li>
                    <li>• Log data and analytics information</li>
                    <li>• Cookies and similar tracking technologies</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* How We Use Your Information */}
          <Card className="glass-card">
            <CardContent className="p-8">
              <div className="flex items-center space-x-3 mb-6">
                <FileText className="w-6 h-6 text-green-500" />
                <h2 className="text-2xl font-bold">How We Use Your Information</h2>
              </div>

              <div className="space-y-4 text-muted-foreground">
                <p>
                  <strong>Resume Optimization:</strong> We analyze your resume content to provide ATS scoring,
                  optimization suggestions, and personalized recommendations.
                </p>

                <p>
                  <strong>Job Matching:</strong> We use your skills and experience to recommend relevant job
                  opportunities and calculate fit scores.
                </p>

                <p>
                  <strong>Platform Improvement:</strong> We analyze usage patterns to improve our AI algorithms and user
                  experience.
                </p>

                <p>
                  <strong>Communication:</strong> We send you important updates, feature announcements, and customer
                  support responses.
                </p>

                <p>
                  <strong>Security:</strong> We monitor for fraudulent activity and protect against security threats.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Data Security */}
          <Card className="glass-card">
            <CardContent className="p-8">
              <div className="flex items-center space-x-3 mb-6">
                <Shield className="w-6 h-6 text-purple-500" />
                <h2 className="text-2xl font-bold">Data Security</h2>
              </div>

              <div className="space-y-4 text-muted-foreground">
                <p>We implement industry-leading security measures to protect your data:</p>

                <ul className="space-y-2">
                  <li>
                    • <strong>Encryption:</strong> All data is encrypted in transit (TLS 1.3) and at rest (AES-256)
                  </li>
                  <li>
                    • <strong>Access Controls:</strong> Strict access controls and authentication requirements
                  </li>
                  <li>
                    • <strong>Regular Audits:</strong> Regular security audits and penetration testing
                  </li>
                  <li>
                    • <strong>Compliance:</strong> SOC 2 Type II compliance and GDPR/CCPA adherence
                  </li>
                  <li>
                    • <strong>Monitoring:</strong> 24/7 security monitoring and incident response
                  </li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Data Sharing */}
          <Card className="glass-card">
            <CardContent className="p-8">
              <div className="flex items-center space-x-3 mb-6">
                <Globe className="w-6 h-6 text-orange-500" />
                <h2 className="text-2xl font-bold">Data Sharing</h2>
              </div>

              <div className="space-y-4 text-muted-foreground">
                <p>
                  We do not sell, rent, or trade your personal information. We may share your data only in these limited
                  circumstances:
                </p>

                <ul className="space-y-2">
                  <li>
                    • <strong>Service Providers:</strong> Trusted third-party services that help us operate our platform
                    (hosting, analytics, payment processing)
                  </li>
                  <li>
                    • <strong>Legal Requirements:</strong> When required by law, court order, or to protect our rights
                    and safety
                  </li>
                  <li>
                    • <strong>Business Transfers:</strong> In the event of a merger, acquisition, or sale of assets
                    (with user notification)
                  </li>
                  <li>
                    • <strong>With Your Consent:</strong> When you explicitly authorize us to share specific information
                  </li>
                </ul>

                <p className="mt-4">
                  <strong>
                    We never share your resume content or personal information with employers or recruiters without your
                    explicit consent.
                  </strong>
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Your Rights */}
          <Card className="glass-card">
            <CardContent className="p-8">
              <div className="flex items-center space-x-3 mb-6">
                <UserCheck className="w-6 h-6 text-blue-500" />
                <h2 className="text-2xl font-bold">Your Rights and Choices</h2>
              </div>

              <div className="space-y-4 text-muted-foreground">
                <p>You have the following rights regarding your personal data:</p>

                <ul className="space-y-2">
                  <li>
                    • <strong>Access:</strong> Request a copy of all personal data we have about you
                  </li>
                  <li>
                    • <strong>Correction:</strong> Update or correct any inaccurate information
                  </li>
                  <li>
                    • <strong>Deletion:</strong> Request deletion of your account and all associated data
                  </li>
                  <li>
                    • <strong>Portability:</strong> Export your data in a machine-readable format
                  </li>
                  <li>
                    • <strong>Opt-out:</strong> Unsubscribe from marketing communications at any time
                  </li>
                  <li>
                    • <strong>Restriction:</strong> Limit how we process your data in certain circumstances
                  </li>
                </ul>

                <p className="mt-4">
                  To exercise any of these rights, contact us at privacy@jobfit.ai or through your account settings.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Cookies and Tracking */}
          <Card className="glass-card">
            <CardContent className="p-8">
              <div className="flex items-center space-x-3 mb-6">
                <Eye className="w-6 h-6 text-green-500" />
                <h2 className="text-2xl font-bold">Cookies and Tracking</h2>
              </div>

              <div className="space-y-4 text-muted-foreground">
                <p>We use cookies and similar technologies to:</p>

                <ul className="space-y-2">
                  <li>• Remember your preferences and settings</li>
                  <li>• Keep you logged in to your account</li>
                  <li>• Analyze how you use our platform</li>
                  <li>• Improve our services and user experience</li>
                </ul>

                <p className="mt-4">
                  You can control cookies through your browser settings. However, disabling certain cookies may limit
                  platform functionality.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <Card className="glass-card">
            <CardContent className="p-8">
              <div className="flex items-center space-x-3 mb-6">
                <Lock className="w-6 h-6 text-purple-500" />
                <h2 className="text-2xl font-bold">Contact Us</h2>
              </div>

              <div className="space-y-4 text-muted-foreground">
                <p>If you have any questions about this Privacy Policy or our data practices, please contact us:</p>

                <div className="space-y-2">
                  <p>
                    <strong>Email:</strong> privacy@jobfit.ai
                  </p>
                  <p>
                    <strong>Address:</strong> JobFit AI, Inc.
                    <br />
                    123 Innovation Drive
                    <br />
                    San Francisco, CA 94105
                  </p>
                  <p>
                    <strong>Phone:</strong> +1 (555) 123-4567
                  </p>
                </div>

                <p className="mt-4">We will respond to your inquiry within 30 days.</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Footer CTA */}
        <div className="mt-20 text-center">
          <Card className="glass-card max-w-2xl mx-auto">
            <CardContent className="p-12">
              <Shield className="w-16 h-16 text-green-500 mx-auto mb-6" />
              <h2 className="text-3xl font-bold mb-4">Ready to Get Started?</h2>
              <p className="text-muted-foreground mb-8">
                Your privacy is protected. Start optimizing your resume with confidence using JobFit AI.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
                  Start Free Analysis
                </Button>
                <Button size="lg" variant="outline" className="glass-button bg-transparent">
                  Learn More
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
