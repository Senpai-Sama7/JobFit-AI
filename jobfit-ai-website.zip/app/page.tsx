"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Upload,
  Search,
  Edit,
  Download,
  CheckCircle,
  Star,
  Users,
  TrendingUp,
  FileText,
  Zap,
  Target,
} from "lucide-react"
import Link from "next/link"
import { ThemeToggle } from "@/components/theme-toggle"
import { FileUpload } from "@/components/file-upload"

export default function HomePage() {
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      setUploadedFile(file)
    }
  }

  const handleDragOver = (event: React.DragEvent) => {
    event.preventDefault()
  }

  const handleDrop = (event: React.DragEvent) => {
    event.preventDefault()
    const file = event.dataTransfer.files[0]
    if (file) {
      setUploadedFile(file)
    }
  }

  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className="glass-card border-b border-white/10 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold">JobFit AI</span>
          </div>
          <div className="hidden md:flex items-center space-x-6">
            <Link href="#features" className="text-muted-foreground hover:text-foreground transition-colors">
              Features
            </Link>
            <Link href="/pricing" className="text-muted-foreground hover:text-foreground transition-colors">
              Pricing
            </Link>
            <Link href="/faq" className="text-muted-foreground hover:text-foreground transition-colors">
              FAQ
            </Link>
            <ThemeToggle />
            <Button variant="outline" className="glass-button bg-transparent">
              Sign In
            </Button>
            <Button className="bg-blue-600 hover:bg-blue-700">Get Started</Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20 text-center">
        <div className="max-w-4xl mx-auto">
          <Badge className="mb-6 bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
            <Star className="w-4 h-4 mr-1" />
            AI-Powered Resume Optimization
          </Badge>
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Land Your Dream Job with an AI-Perfected Resume
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Transform your resume with intelligent AI analysis, ATS optimization, and personalized recommendations. Get
            more interviews and land better jobs.
          </p>

          {/* File Upload Area */}
          <div className="max-w-md mx-auto mb-8">
            <FileUpload onFileUpload={(file) => console.log("Uploaded:", file)} />
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-lg px-8">
              Analyze My Resume
            </Button>
            <Button size="lg" variant="outline" className="glass-button text-lg px-8 bg-transparent">
              Learn More
            </Button>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="container mx-auto px-4 py-20">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">How JobFit AI Works</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Our intelligent platform transforms your resume in four simple steps
          </p>
        </div>

        <div className="grid md:grid-cols-4 gap-8">
          {[
            {
              icon: Upload,
              title: "Upload",
              description: "Upload your current resume in any format. Our AI supports PDF, DOCX, and more.",
              step: "01",
            },
            {
              icon: Search,
              title: "Analyze",
              description: "Our AI instantly scores it against ATS systems and analyzes your skills and experience.",
              step: "02",
            },
            {
              icon: Edit,
              title: "Optimize",
              description: "Receive actionable feedback and tailor your resume with our intelligent editor.",
              step: "03",
            },
            {
              icon: Download,
              title: "Succeed",
              description: "Download your optimized resume and apply with confidence to land more interviews.",
              step: "04",
            },
          ].map((item, index) => (
            <Card key={index} className="glass-card text-center p-6 hover:shadow-lg transition-shadow">
              <CardContent className="p-0">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <item.icon className="w-8 h-8 text-white" />
                </div>
                <div className="text-sm font-bold text-blue-600 mb-2">STEP {item.step}</div>
                <h3 className="text-xl font-bold mb-3">{item.title}</h3>
                <p className="text-muted-foreground">{item.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Features Showcase */}
      <section id="features" className="container mx-auto px-4 py-20">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Powerful AI Features</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Advanced AI technology designed to maximize your job search success
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            {
              icon: FileText,
              title: "AI Resume Parsing",
              description:
                "Instantly extracts and structures your career history with advanced natural language processing.",
            },
            {
              icon: TrendingUp,
              title: "ATS Scoring",
              description: "See how your resume scores against Applicant Tracking Systems with detailed analytics.",
            },
            {
              icon: Target,
              title: "Role Recommendations",
              description: "Discover jobs that match your unique skills with our intelligent matching algorithm.",
            },
            {
              icon: Edit,
              title: "Tailored Generation",
              description: "Automatically create custom resumes for specific job descriptions and requirements.",
            },
          ].map((feature, index) => (
            <Card key={index} className="glass-card p-6 hover:shadow-lg transition-shadow">
              <CardContent className="p-0">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center mb-4">
                  <feature.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-bold mb-3">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Stats Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="glass-card rounded-2xl p-12">
          <div className="grid md:grid-cols-3 gap-8 text-center">
            {[
              { icon: Users, number: "50,000+", label: "Resumes Optimized" },
              { icon: TrendingUp, number: "85%", label: "Interview Rate Increase" },
              { icon: CheckCircle, number: "4.9/5", label: "User Satisfaction" },
            ].map((stat, index) => (
              <div key={index}>
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <stat.icon className="w-8 h-8 text-white" />
                </div>
                <div className="text-3xl font-bold text-blue-600 mb-2">{stat.number}</div>
                <div className="text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="container mx-auto px-4 py-20">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">What Our Users Say</h2>
          <p className="text-xl text-muted-foreground">
            Join thousands of successful job seekers who transformed their careers
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {[
            {
              name: "Sarah Chen",
              role: "Software Engineer",
              company: "Google",
              image: "/placeholder.svg?height=60&width=60",
              quote: "JobFit AI helped me land my dream job at Google. The ATS optimization was game-changing!",
            },
            {
              name: "Michael Rodriguez",
              role: "Marketing Manager",
              company: "Meta",
              image: "/placeholder.svg?height=60&width=60",
              quote: "I went from 2% to 40% interview rate after using JobFit AI. The tailored resumes work!",
            },
            {
              name: "Emily Johnson",
              role: "Data Scientist",
              company: "Netflix",
              image: "/placeholder.svg?height=60&width=60",
              quote: "The AI recommendations were spot-on. I got 3 job offers within a month of optimization.",
            },
          ].map((testimonial, index) => (
            <Card key={index} className="glass-card p-6">
              <CardContent className="p-0">
                <div className="flex items-center mb-4">
                  <img
                    src={testimonial.image || "/placeholder.svg"}
                    alt={testimonial.name}
                    className="w-12 h-12 rounded-full mr-4"
                  />
                  <div>
                    <div className="font-bold">{testimonial.name}</div>
                    <div className="text-sm text-muted-foreground">
                      {testimonial.role} at {testimonial.company}
                    </div>
                  </div>
                </div>
                <p className="text-muted-foreground italic">"{testimonial.quote}"</p>
                <div className="flex mt-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Final CTA */}
      <section className="container mx-auto px-4 py-20">
        <div className="glass-card rounded-2xl p-12 text-center">
          <h2 className="text-4xl font-bold mb-4">Ready to Transform Your Career?</h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join thousands of professionals who have already optimized their resumes and landed their dream jobs with
            JobFit AI.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-lg px-8">
              Start Free Analysis
            </Button>
            <Button size="lg" variant="outline" className="glass-button text-lg px-8 bg-transparent">
              View Pricing
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="glass-card border-t border-white/10 mt-20">
        <div className="container mx-auto px-4 py-12">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                  <Zap className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold">JobFit AI</span>
              </div>
              <p className="text-muted-foreground">Empowering job seekers with AI-powered resume optimization.</p>
            </div>
            <div>
              <h3 className="font-bold mb-4">Product</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li>
                  <Link href="#features" className="hover:text-foreground transition-colors">
                    Features
                  </Link>
                </li>
                <li>
                  <Link href="/pricing" className="hover:text-foreground transition-colors">
                    Pricing
                  </Link>
                </li>
                <li>
                  <Link href="/dashboard" className="hover:text-foreground transition-colors">
                    Dashboard
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold mb-4">Support</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li>
                  <Link href="/faq" className="hover:text-foreground transition-colors">
                    FAQ
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-foreground transition-colors">
                    Contact
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-foreground transition-colors">
                    Help Center
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold mb-4">Legal</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li>
                  <Link href="/privacy" className="hover:text-foreground transition-colors">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-foreground transition-colors">
                    Terms of Service
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-white/10 mt-8 pt-8 text-center text-muted-foreground">
            <p>&copy; 2024 JobFit AI. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
