"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, Star, Zap, Crown, Rocket, CreditCard } from "lucide-react"
import Link from "next/link"
import { ThemeToggle } from "@/components/theme-toggle"
import { loadStripe } from "@stripe/stripe-js"

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!)

export default function PricingPage() {
  const [isLoading, setIsLoading] = useState<string | null>(null)

  const plans = [
    {
      id: "free",
      name: "Free",
      price: "$0",
      period: "forever",
      description: "Perfect for getting started with resume optimization",
      icon: Zap,
      popular: false,
      features: [
        "1 resume upload per month",
        "Basic ATS scoring",
        "Standard resume templates",
        "Email support",
        "Basic optimization tips",
      ],
      limitations: ["Limited to 1 resume", "Basic analysis only", "No role recommendations"],
    },
    {
      id: "pro",
      name: "Pro",
      price: "$19",
      period: "per month",
      description: "Ideal for active job seekers who want comprehensive optimization",
      icon: Star,
      popular: true,
      features: [
        "Unlimited resume uploads",
        "Advanced ATS scoring & analysis",
        "AI-powered role recommendations",
        "Custom resume tailoring",
        "Premium templates",
        "Priority email support",
        "Interview preparation tips",
        "Skills gap analysis",
        "Industry-specific optimization",
      ],
      limitations: [],
    },
    {
      id: "business",
      name: "Business",
      price: "$49",
      period: "per month",
      description: "Perfect for career coaches, recruiters, and HR professionals",
      icon: Crown,
      popular: false,
      features: [
        "Everything in Pro",
        "Bulk resume processing",
        "Team collaboration tools",
        "White-label options",
        "API access",
        "Advanced analytics dashboard",
        "Custom integrations",
        "Dedicated account manager",
        "Phone support",
        "Custom training sessions",
      ],
      limitations: [],
    },
  ]

  const handleSubscribe = async (planId: string) => {
    if (planId === "free") {
      // Redirect to signup for free plan
      window.location.href = "/auth/signup"
      return
    }

    setIsLoading(planId)

    try {
      const response = await fetch("/api/subscribe", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("auth_token")}`,
        },
        body: JSON.stringify({ planId }),
      })

      const { clientSecret, error } = await response.json()

      if (error) {
        alert(error)
        return
      }

      const stripe = await stripePromise
      if (!stripe) return

      const { error: stripeError } = await stripe.confirmPayment({
        clientSecret,
        confirmParams: {
          return_url: `${window.location.origin}/dashboard?subscription=success`,
        },
      })

      if (stripeError) {
        alert(stripeError.message)
      }
    } catch (error) {
      console.error("Subscription error:", error)
      alert("Failed to start subscription. Please try again.")
    } finally {
      setIsLoading(null)
    }
  }

  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className="glass-card border-b border-white/10 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold">JobFit AI</span>
          </Link>
          <div className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-muted-foreground hover:text-foreground transition-colors">
              Home
            </Link>
            <Link href="/dashboard" className="text-muted-foreground hover:text-foreground transition-colors">
              Dashboard
            </Link>
            <Link href="/faq" className="text-muted-foreground hover:text-foreground transition-colors">
              FAQ
            </Link>
            <ThemeToggle />
            <Button variant="outline" className="glass-button bg-transparent">
              Sign In
            </Button>
            <Button className="bg-blue-600 hover:bg-blue-700">Get Started</Button>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <Badge className="mb-6 bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
            <Rocket className="w-4 h-4 mr-1" />
            Choose Your Plan
          </Badge>
          <h1 className="text-5xl font-bold mb-6">Simple, Transparent Pricing</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Choose the perfect plan for your job search needs. Upgrade or downgrade at any time.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <Card
              key={index}
              className={`glass-card relative ${plan.popular ? "ring-2 ring-blue-500 scale-105" : ""} hover:shadow-lg transition-all`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-blue-600 text-white px-4 py-1">Most Popular</Badge>
                </div>
              )}

              <CardHeader className="text-center pb-8">
                <div
                  className={`w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center ${
                    plan.popular
                      ? "bg-gradient-to-br from-blue-500 to-purple-600"
                      : "bg-gradient-to-br from-gray-400 to-gray-600"
                  }`}
                >
                  <plan.icon className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-2xl font-bold">{plan.name}</CardTitle>
                <div className="mt-4">
                  <span className="text-4xl font-bold">{plan.price}</span>
                  <span className="text-muted-foreground">/{plan.period}</span>
                </div>
                <p className="text-muted-foreground mt-2">{plan.description}</p>
              </CardHeader>

              <CardContent className="space-y-6">
                <div className="space-y-3">
                  {plan.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-center space-x-3">
                      <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">{feature}</span>
                    </div>
                  ))}
                </div>

                <Button
                  className={`w-full ${
                    plan.popular ? "bg-blue-600 hover:bg-blue-700" : "bg-gray-600 hover:bg-gray-700"
                  }`}
                  size="lg"
                  onClick={() => handleSubscribe(plan.id)}
                  disabled={isLoading === plan.id}
                >
                  {isLoading === plan.id ? (
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>Processing...</span>
                    </div>
                  ) : (
                    <>
                      <CreditCard className="w-4 h-4 mr-2" />
                      {plan.name === "Free" ? "Get Started Free" : `Choose ${plan.name}`}
                    </>
                  )}
                </Button>

                {plan.name === "Business" && (
                  <p className="text-center text-sm text-muted-foreground">
                    Contact us for custom enterprise solutions
                  </p>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* FAQ Section */}
        <div className="mt-20">
          <h2 className="text-3xl font-bold text-center mb-12">Frequently Asked Questions</h2>

          <div className="max-w-3xl mx-auto space-y-6">
            {[
              {
                question: "Can I change my plan at any time?",
                answer:
                  "Yes, you can upgrade or downgrade your plan at any time. Changes will be reflected in your next billing cycle.",
              },
              {
                question: "Is there a free trial for paid plans?",
                answer:
                  "We offer a generous free plan that you can use indefinitely. You can upgrade to Pro or Business at any time to access advanced features.",
              },
              {
                question: "What payment methods do you accept?",
                answer:
                  "We accept all major credit cards (Visa, MasterCard, American Express) and PayPal for your convenience.",
              },
              {
                question: "Can I cancel my subscription?",
                answer:
                  "Yes, you can cancel your subscription at any time from your account settings. You'll continue to have access until the end of your billing period.",
              },
              {
                question: "Do you offer refunds?",
                answer:
                  "We offer a 30-day money-back guarantee for all paid plans. If you're not satisfied, contact us for a full refund.",
              },
            ].map((faq, index) => (
              <Card key={index} className="glass-card">
                <CardContent className="p-6">
                  <h3 className="font-bold text-lg mb-2">{faq.question}</h3>
                  <p className="text-muted-foreground">{faq.answer}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="mt-20 text-center">
          <Card className="glass-card max-w-2xl mx-auto">
            <CardContent className="p-12">
              <h2 className="text-3xl font-bold mb-4">Ready to Transform Your Career?</h2>
              <p className="text-muted-foreground mb-8">
                Join thousands of professionals who have already optimized their resumes and landed their dream jobs.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
                  Start Free Today
                </Button>
                <Button size="lg" variant="outline" className="glass-button bg-transparent">
                  Contact Sales
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
