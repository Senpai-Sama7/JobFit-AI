"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Upload,
  FileText,
  Download,
  Edit,
  Trash2,
  Eye,
  TrendingUp,
  Users,
  Target,
  Plus,
  Star,
  Briefcase,
  Clock,
} from "lucide-react"
import Link from "next/link"
import { ThemeToggle } from "@/components/theme-toggle"

export default function Dashboard() {
  const [resumes] = useState([
    {
      id: 1,
      name: "Software Engineer Resume",
      atsScore: 85,
      lastModified: "2 hours ago",
      status: "optimized",
      thumbnail: "/placeholder.svg?height=120&width=80",
    },
    {
      id: 2,
      name: "Product Manager Resume",
      atsScore: 72,
      lastModified: "1 day ago",
      status: "needs-work",
      thumbnail: "/placeholder.svg?height=120&width=80",
    },
    {
      id: 3,
      name: "Data Scientist Resume",
      atsScore: 91,
      lastModified: "3 days ago",
      status: "excellent",
      thumbnail: "/placeholder.svg?height=120&width=80",
    },
  ])

  const [roleRecommendations] = useState([
    {
      title: "Senior Software Engineer",
      company: "Google",
      fitScore: 95,
      location: "Mountain View, CA",
      salary: "$180k - $250k",
    },
    {
      title: "Full Stack Developer",
      company: "Meta",
      fitScore: 88,
      location: "Menlo Park, CA",
      salary: "$160k - $220k",
    },
    {
      title: "Frontend Engineer",
      company: "Netflix",
      fitScore: 82,
      location: "Los Gatos, CA",
      salary: "$150k - $200k",
    },
  ])

  const getScoreColor = (score: number) => {
    if (score >= 85) return "text-green-600"
    if (score >= 70) return "text-yellow-600"
    return "text-red-600"
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "excellent":
        return <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">Excellent</Badge>
      case "optimized":
        return <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">Optimized</Badge>
      case "needs-work":
        return (
          <Badge className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200">Needs Work</Badge>
        )
      default:
        return <Badge variant="secondary">Unknown</Badge>
    }
  }

  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className="glass-card border-b border-white/10 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
              <FileText className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold">JobFit AI</span>
          </Link>
          <div className="flex items-center space-x-4">
            <ThemeToggle />
            <Button variant="outline" className="glass-button bg-transparent">
              <Upload className="w-4 h-4 mr-2" />
              Upload Resume
            </Button>
            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full"></div>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
          <p className="text-muted-foreground">Manage your resumes and track your job search progress</p>
        </div>

        {/* Stats Overview */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="glass-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Average ATS Score</p>
                  <p className="text-2xl font-bold text-blue-600">83</p>
                </div>
                <TrendingUp className="w-8 h-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="glass-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Resumes</p>
                  <p className="text-2xl font-bold">3</p>
                </div>
                <FileText className="w-8 h-8 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="glass-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Job Matches</p>
                  <p className="text-2xl font-bold">12</p>
                </div>
                <Target className="w-8 h-8 text-purple-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="glass-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Applications</p>
                  <p className="text-2xl font-bold">8</p>
                </div>
                <Users className="w-8 h-8 text-orange-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Recent Resumes */}
          <div className="lg:col-span-2">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">Recent Resumes</h2>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                Upload New Resume
              </Button>
            </div>

            <div className="space-y-4">
              {resumes.map((resume) => (
                <Card key={resume.id} className="glass-card hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-16 h-20 bg-gray-100 dark:bg-gray-800 rounded border flex items-center justify-center">
                        <FileText className="w-8 h-8 text-gray-400" />
                      </div>

                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-bold text-lg">{resume.name}</h3>
                          {getStatusBadge(resume.status)}
                        </div>

                        <div className="flex items-center space-x-4 mb-3">
                          <div className="flex items-center space-x-2">
                            <span className="text-sm text-muted-foreground">ATS Score:</span>
                            <span className={`font-bold ${getScoreColor(resume.atsScore)}`}>{resume.atsScore}%</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Clock className="w-4 h-4 text-muted-foreground" />
                            <span className="text-sm text-muted-foreground">{resume.lastModified}</span>
                          </div>
                        </div>

                        <Progress value={resume.atsScore} className="mb-4" />

                        <div className="flex space-x-2">
                          <Button size="sm" variant="outline" className="glass-button bg-transparent">
                            <Eye className="w-4 h-4 mr-1" />
                            View
                          </Button>
                          <Button size="sm" variant="outline" className="glass-button bg-transparent">
                            <Edit className="w-4 h-4 mr-1" />
                            Tailor
                          </Button>
                          <Button size="sm" variant="outline" className="glass-button bg-transparent">
                            <Download className="w-4 h-4 mr-1" />
                            Export
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="glass-button text-red-600 hover:text-red-700 bg-transparent"
                          >
                            <Trash2 className="w-4 h-4 mr-1" />
                            Delete
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* AI Role Recommendations */}
          <div>
            <h2 className="text-2xl font-bold mb-6">AI Role Recommendations</h2>

            <div className="space-y-4">
              {roleRecommendations.map((role, index) => (
                <Card key={index} className="glass-card hover:shadow-lg transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="font-bold">{role.title}</h3>
                        <p className="text-sm text-muted-foreground">{role.company}</p>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Star className="w-4 h-4 text-yellow-500" />
                        <span className="text-sm font-bold">{role.fitScore}%</span>
                      </div>
                    </div>

                    <div className="space-y-2 mb-4">
                      <div className="flex items-center space-x-2">
                        <Briefcase className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm">{role.location}</span>
                      </div>
                      <div className="text-sm font-medium text-green-600">{role.salary}</div>
                    </div>

                    <Progress value={role.fitScore} className="mb-3" />

                    <Button size="sm" className="w-full bg-blue-600 hover:bg-blue-700">
                      View Details
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Button variant="outline" className="w-full mt-4 glass-button bg-transparent">
              View All Recommendations
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
