"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Save, Download, Eye, Plus, Trash2, FileText, Zap, Lightbulb, AlertCircle, CheckCircle, X } from "lucide-react"
import Link from "next/link"

export default function ResumeEditor() {
  const [atsScore, setAtsScore] = useState(78)
  const [isPreview, setIsPreview] = useState(false)
  const [resumeData, setResumeData] = useState({
    personalInfo: {
      name: "John Doe",
      email: "john.doe@email.com",
      phone: "(555) 123-4567",
      location: "San Francisco, CA",
      linkedin: "linkedin.com/in/johndoe",
      website: "johndoe.dev",
    },
    summary:
      "Experienced software engineer with 5+ years of expertise in full-stack development, specializing in React, Node.js, and cloud technologies. Proven track record of delivering scalable applications and leading cross-functional teams.",
    experience: [
      {
        id: 1,
        title: "Senior Software Engineer",
        company: "Tech Corp",
        location: "San Francisco, CA",
        startDate: "2022-01",
        endDate: "Present",
        description:
          "• Led development of microservices architecture serving 1M+ users\n• Improved application performance by 40% through optimization\n• Mentored 3 junior developers and conducted code reviews",
      },
      {
        id: 2,
        title: "Software Engineer",
        company: "StartupXYZ",
        location: "San Francisco, CA",
        startDate: "2020-06",
        endDate: "2021-12",
        description:
          "• Built responsive web applications using React and TypeScript\n• Implemented CI/CD pipelines reducing deployment time by 60%\n• Collaborated with design team to improve user experience",
      },
    ],
    education: [
      {
        id: 1,
        degree: "Bachelor of Science in Computer Science",
        school: "University of California, Berkeley",
        location: "Berkeley, CA",
        graduationDate: "2020-05",
        gpa: "3.8",
      },
    ],
    skills: ["JavaScript", "TypeScript", "React", "Node.js", "Python", "AWS", "Docker", "PostgreSQL"],
  })

  const [suggestions] = useState([
    {
      type: "improvement",
      category: "ATS Optimization",
      title: "Add more industry keywords",
      description: "Include keywords like 'agile', 'scrum', and 'DevOps' to improve ATS matching.",
      impact: "high",
    },
    {
      type: "warning",
      category: "Formatting",
      title: "Inconsistent date format",
      description: "Use consistent date formatting throughout your resume (MM/YYYY).",
      impact: "medium",
    },
    {
      type: "success",
      category: "Content",
      title: "Strong action verbs",
      description: "Great use of action verbs like 'Led', 'Improved', and 'Implemented'.",
      impact: "positive",
    },
  ])

  const addExperience = () => {
    const newExp = {
      id: Date.now(),
      title: "",
      company: "",
      location: "",
      startDate: "",
      endDate: "",
      description: "",
    }
    setResumeData({
      ...resumeData,
      experience: [...resumeData.experience, newExp],
    })
  }

  const removeExperience = (id: number) => {
    setResumeData({
      ...resumeData,
      experience: resumeData.experience.filter((exp) => exp.id !== id),
    })
  }

  const updateExperience = (id: number, field: string, value: string) => {
    setResumeData({
      ...resumeData,
      experience: resumeData.experience.map((exp) => (exp.id === id ? { ...exp, [field]: value } : exp)),
    })
  }

  const addSkill = (skill: string) => {
    if (skill && !resumeData.skills.includes(skill)) {
      setResumeData({
        ...resumeData,
        skills: [...resumeData.skills, skill],
      })
    }
  }

  const removeSkill = (skill: string) => {
    setResumeData({
      ...resumeData,
      skills: resumeData.skills.filter((s) => s !== skill),
    })
  }

  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className="glass-card border-b border-white/10 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/dashboard" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
              <FileText className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold">Resume Editor</span>
          </Link>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <span className="text-sm text-muted-foreground">ATS Score:</span>
              <Badge
                className={`${atsScore >= 80 ? "bg-green-100 text-green-800" : atsScore >= 60 ? "bg-yellow-100 text-yellow-800" : "bg-red-100 text-red-800"}`}
              >
                {atsScore}%
              </Badge>
            </div>
            <Button variant="outline" className="glass-button bg-transparent" onClick={() => setIsPreview(!isPreview)}>
              <Eye className="w-4 h-4 mr-2" />
              {isPreview ? "Edit" : "Preview"}
            </Button>
            <Button variant="outline" className="glass-button bg-transparent">
              <Save className="w-4 h-4 mr-2" />
              Save
            </Button>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Download className="w-4 h-4 mr-2" />
              Export PDF
            </Button>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* AI Suggestions Sidebar */}
          <div className="lg:col-span-1">
            <Card className="glass-card sticky top-24">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Zap className="w-5 h-5 text-blue-500" />
                  <span>AI Suggestions</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">ATS Score</span>
                    <span className="text-sm text-muted-foreground">{atsScore}%</span>
                  </div>
                  <Progress value={atsScore} className="h-2" />
                </div>

                <Separator />

                <div className="space-y-3">
                  {suggestions.map((suggestion, index) => (
                    <div key={index} className="p-3 rounded-lg border border-white/10 bg-white/5">
                      <div className="flex items-start space-x-2">
                        {suggestion.type === "improvement" && <Lightbulb className="w-4 h-4 text-yellow-500 mt-0.5" />}
                        {suggestion.type === "warning" && <AlertCircle className="w-4 h-4 text-orange-500 mt-0.5" />}
                        {suggestion.type === "success" && <CheckCircle className="w-4 h-4 text-green-500 mt-0.5" />}
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-1">
                            <span className="text-xs font-medium">{suggestion.category}</span>
                            <Badge
                              variant="outline"
                              className={`text-xs ${
                                suggestion.impact === "high"
                                  ? "border-red-500 text-red-500"
                                  : suggestion.impact === "medium"
                                    ? "border-yellow-500 text-yellow-500"
                                    : "border-green-500 text-green-500"
                              }`}
                            >
                              {suggestion.impact === "positive" ? "Good" : suggestion.impact}
                            </Badge>
                          </div>
                          <p className="text-sm font-medium mb-1">{suggestion.title}</p>
                          <p className="text-xs text-muted-foreground">{suggestion.description}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Editor */}
          <div className="lg:col-span-3">
            {isPreview ? (
              /* Resume Preview */
              <Card className="glass-card">
                <CardContent className="p-8">
                  <div className="max-w-2xl mx-auto bg-white text-black p-8 shadow-lg">
                    {/* Header */}
                    <div className="text-center mb-6">
                      <h1 className="text-3xl font-bold mb-2">{resumeData.personalInfo.name}</h1>
                      <div className="flex flex-wrap justify-center gap-4 text-sm text-gray-600">
                        <span>{resumeData.personalInfo.email}</span>
                        <span>{resumeData.personalInfo.phone}</span>
                        <span>{resumeData.personalInfo.location}</span>
                      </div>
                      <div className="flex flex-wrap justify-center gap-4 text-sm text-blue-600 mt-2">
                        <span>{resumeData.personalInfo.linkedin}</span>
                        <span>{resumeData.personalInfo.website}</span>
                      </div>
                    </div>

                    {/* Summary */}
                    <div className="mb-6">
                      <h2 className="text-xl font-bold mb-3 border-b-2 border-gray-300">Professional Summary</h2>
                      <p className="text-gray-700">{resumeData.summary}</p>
                    </div>

                    {/* Experience */}
                    <div className="mb-6">
                      <h2 className="text-xl font-bold mb-3 border-b-2 border-gray-300">Professional Experience</h2>
                      {resumeData.experience.map((exp) => (
                        <div key={exp.id} className="mb-4">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <h3 className="font-bold">{exp.title}</h3>
                              <p className="text-gray-600">
                                {exp.company} • {exp.location}
                              </p>
                            </div>
                            <span className="text-sm text-gray-500">
                              {exp.startDate} - {exp.endDate}
                            </span>
                          </div>
                          <div className="text-gray-700 whitespace-pre-line">{exp.description}</div>
                        </div>
                      ))}
                    </div>

                    {/* Education */}
                    <div className="mb-6">
                      <h2 className="text-xl font-bold mb-3 border-b-2 border-gray-300">Education</h2>
                      {resumeData.education.map((edu) => (
                        <div key={edu.id} className="mb-2">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-bold">{edu.degree}</h3>
                              <p className="text-gray-600">
                                {edu.school} • {edu.location}
                              </p>
                            </div>
                            <span className="text-sm text-gray-500">{edu.graduationDate}</span>
                          </div>
                          {edu.gpa && <p className="text-sm text-gray-600">GPA: {edu.gpa}</p>}
                        </div>
                      ))}
                    </div>

                    {/* Skills */}
                    <div>
                      <h2 className="text-xl font-bold mb-3 border-b-2 border-gray-300">Technical Skills</h2>
                      <div className="flex flex-wrap gap-2">
                        {resumeData.skills.map((skill, index) => (
                          <span key={index} className="px-3 py-1 bg-gray-200 text-gray-700 rounded-full text-sm">
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ) : (
              /* Resume Editor */
              <Tabs defaultValue="personal" className="space-y-6">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="personal">Personal</TabsTrigger>
                  <TabsTrigger value="experience">Experience</TabsTrigger>
                  <TabsTrigger value="education">Education</TabsTrigger>
                  <TabsTrigger value="skills">Skills</TabsTrigger>
                </TabsList>

                <TabsContent value="personal">
                  <Card className="glass-card">
                    <CardHeader>
                      <CardTitle>Personal Information</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="name">Full Name</Label>
                          <Input
                            id="name"
                            value={resumeData.personalInfo.name}
                            onChange={(e) =>
                              setResumeData({
                                ...resumeData,
                                personalInfo: { ...resumeData.personalInfo, name: e.target.value },
                              })
                            }
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="email">Email</Label>
                          <Input
                            id="email"
                            type="email"
                            value={resumeData.personalInfo.email}
                            onChange={(e) =>
                              setResumeData({
                                ...resumeData,
                                personalInfo: { ...resumeData.personalInfo, email: e.target.value },
                              })
                            }
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="phone">Phone</Label>
                          <Input
                            id="phone"
                            value={resumeData.personalInfo.phone}
                            onChange={(e) =>
                              setResumeData({
                                ...resumeData,
                                personalInfo: { ...resumeData.personalInfo, phone: e.target.value },
                              })
                            }
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="location">Location</Label>
                          <Input
                            id="location"
                            value={resumeData.personalInfo.location}
                            onChange={(e) =>
                              setResumeData({
                                ...resumeData,
                                personalInfo: { ...resumeData.personalInfo, location: e.target.value },
                              })
                            }
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="linkedin">LinkedIn</Label>
                          <Input
                            id="linkedin"
                            value={resumeData.personalInfo.linkedin}
                            onChange={(e) =>
                              setResumeData({
                                ...resumeData,
                                personalInfo: { ...resumeData.personalInfo, linkedin: e.target.value },
                              })
                            }
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="website">Website</Label>
                          <Input
                            id="website"
                            value={resumeData.personalInfo.website}
                            onChange={(e) =>
                              setResumeData({
                                ...resumeData,
                                personalInfo: { ...resumeData.personalInfo, website: e.target.value },
                              })
                            }
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="summary">Professional Summary</Label>
                        <Textarea
                          id="summary"
                          rows={4}
                          value={resumeData.summary}
                          onChange={(e) => setResumeData({ ...resumeData, summary: e.target.value })}
                        />
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="experience">
                  <Card className="glass-card">
                    <CardHeader className="flex flex-row items-center justify-between">
                      <CardTitle>Work Experience</CardTitle>
                      <Button onClick={addExperience} size="sm" className="bg-blue-600 hover:bg-blue-700">
                        <Plus className="w-4 h-4 mr-2" />
                        Add Experience
                      </Button>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      {resumeData.experience.map((exp, index) => (
                        <div key={exp.id} className="p-4 border border-white/10 rounded-lg bg-white/5">
                          <div className="flex justify-between items-start mb-4">
                            <h3 className="font-medium">Experience {index + 1}</h3>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => removeExperience(exp.id)}
                              className="text-red-500 hover:text-red-700"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                          <div className="grid md:grid-cols-2 gap-4 mb-4">
                            <div className="space-y-2">
                              <Label>Job Title</Label>
                              <Input
                                value={exp.title}
                                onChange={(e) => updateExperience(exp.id, "title", e.target.value)}
                              />
                            </div>
                            <div className="space-y-2">
                              <Label>Company</Label>
                              <Input
                                value={exp.company}
                                onChange={(e) => updateExperience(exp.id, "company", e.target.value)}
                              />
                            </div>
                            <div className="space-y-2">
                              <Label>Location</Label>
                              <Input
                                value={exp.location}
                                onChange={(e) => updateExperience(exp.id, "location", e.target.value)}
                              />
                            </div>
                            <div className="grid grid-cols-2 gap-2">
                              <div className="space-y-2">
                                <Label>Start Date</Label>
                                <Input
                                  type="month"
                                  value={exp.startDate}
                                  onChange={(e) => updateExperience(exp.id, "startDate", e.target.value)}
                                />
                              </div>
                              <div className="space-y-2">
                                <Label>End Date</Label>
                                <Input
                                  type="month"
                                  value={exp.endDate}
                                  onChange={(e) => updateExperience(exp.id, "endDate", e.target.value)}
                                />
                              </div>
                            </div>
                          </div>
                          <div className="space-y-2">
                            <Label>Description</Label>
                            <Textarea
                              rows={4}
                              value={exp.description}
                              onChange={(e) => updateExperience(exp.id, "description", e.target.value)}
                              placeholder="• Use bullet points to describe your achievements&#10;• Start with action verbs&#10;• Include quantifiable results"
                            />
                          </div>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="education">
                  <Card className="glass-card">
                    <CardHeader>
                      <CardTitle>Education</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {resumeData.education.map((edu) => (
                        <div key={edu.id} className="p-4 border border-white/10 rounded-lg bg-white/5">
                          <div className="grid md:grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <Label>Degree</Label>
                              <Input value={edu.degree} readOnly />
                            </div>
                            <div className="space-y-2">
                              <Label>School</Label>
                              <Input value={edu.school} readOnly />
                            </div>
                            <div className="space-y-2">
                              <Label>Location</Label>
                              <Input value={edu.location} readOnly />
                            </div>
                            <div className="space-y-2">
                              <Label>Graduation Date</Label>
                              <Input value={edu.graduationDate} readOnly />
                            </div>
                          </div>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="skills">
                  <Card className="glass-card">
                    <CardHeader>
                      <CardTitle>Skills</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex flex-wrap gap-2">
                        {resumeData.skills.map((skill, index) => (
                          <Badge key={index} variant="secondary" className="flex items-center space-x-2">
                            <span>{skill}</span>
                            <button onClick={() => removeSkill(skill)} className="ml-2 hover:text-red-500">
                              <X className="w-3 h-3" />
                            </button>
                          </Badge>
                        ))}
                      </div>
                      <div className="flex space-x-2">
                        <Input
                          placeholder="Add a skill..."
                          onKeyPress={(e) => {
                            if (e.key === "Enter") {
                              addSkill(e.currentTarget.value)
                              e.currentTarget.value = ""
                            }
                          }}
                        />
                        <Button
                          onClick={(e) => {
                            const input = e.currentTarget.previousElementSibling as HTMLInputElement
                            addSkill(input.value)
                            input.value = ""
                          }}
                          size="sm"
                        >
                          <Plus className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
