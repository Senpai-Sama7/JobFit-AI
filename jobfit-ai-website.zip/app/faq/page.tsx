"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { ChevronDown, ChevronUp, Search, Zap, HelpCircle, Shield, CreditCard, FileText, Users } from "lucide-react"
import Link from "next/link"
import { ThemeToggle } from "@/components/theme-toggle"

export default function FAQPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [openItems, setOpenItems] = useState<number[]>([])

  const toggleItem = (index: number) => {
    setOpenItems((prev) => (prev.includes(index) ? prev.filter((i) => i !== index) : [...prev, index]))
  }

  const faqCategories = [
    {
      title: "Getting Started",
      icon: FileText,
      color: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
      faqs: [
        {
          question: "How does JobFit AI work?",
          answer:
            "JobFit AI uses advanced artificial intelligence to analyze your resume against industry standards and ATS systems. Simply upload your resume, and our AI will provide detailed scoring, optimization suggestions, and role recommendations tailored to your experience.",
        },
        {
          question: "What file formats are supported?",
          answer:
            "We support all major resume formats including PDF, DOCX, TXT, MD, RTF, and ODT. Our AI can parse and analyze resumes in any of these formats with high accuracy.",
        },
        {
          question: "How accurate is the ATS scoring?",
          answer:
            "Our ATS scoring system is trained on data from major ATS platforms and has a 95% accuracy rate. We continuously update our algorithms to match the latest ATS requirements and industry standards.",
        },
        {
          question: "Can I use JobFit AI for different industries?",
          answer:
            "Yes! JobFit AI is trained on job data across all major industries including technology, healthcare, finance, marketing, education, and more. Our AI adapts its recommendations based on your target industry.",
        },
      ],
    },
    {
      title: "Privacy & Security",
      icon: Shield,
      color: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
      faqs: [
        {
          question: "Is my resume data secure?",
          answer:
            "Absolutely. We use enterprise-grade encryption (AES-256) to protect your data both in transit and at rest. Your resume data is never shared with third parties and is stored securely in compliance with GDPR and CCPA regulations.",
        },
        {
          question: "Do you share my information with employers?",
          answer:
            "No, we never share your personal information or resume data with employers or third parties without your explicit consent. Your privacy is our top priority.",
        },
        {
          question: "Can I delete my data?",
          answer:
            "Yes, you can delete your account and all associated data at any time from your account settings. We will permanently remove all your information within 30 days of your request.",
        },
        {
          question: "Where is my data stored?",
          answer:
            "Your data is stored in secure, SOC 2 compliant data centers in the United States. We use industry-leading cloud providers with robust security measures and regular security audits.",
        },
      ],
    },
    {
      title: "Billing & Subscriptions",
      icon: CreditCard,
      color: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200",
      faqs: [
        {
          question: "Can I cancel my subscription anytime?",
          answer:
            "Yes, you can cancel your subscription at any time from your account settings. You'll continue to have access to paid features until the end of your current billing period.",
        },
        {
          question: "Do you offer refunds?",
          answer:
            "We offer a 30-day money-back guarantee for all paid plans. If you're not satisfied with our service, contact our support team for a full refund within 30 days of purchase.",
        },
        {
          question: "What payment methods do you accept?",
          answer:
            "We accept all major credit cards (Visa, MasterCard, American Express, Discover) and PayPal. All payments are processed securely through Stripe.",
        },
        {
          question: "Can I upgrade or downgrade my plan?",
          answer:
            "Yes, you can change your plan at any time. Upgrades take effect immediately, while downgrades will take effect at the start of your next billing cycle.",
        },
      ],
    },
    {
      title: "Features & Usage",
      icon: Users,
      color: "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200",
      faqs: [
        {
          question: "How many resumes can I upload?",
          answer:
            "Free users can upload 1 resume per month. Pro users get unlimited uploads, and Business users get unlimited uploads plus bulk processing capabilities.",
        },
        {
          question: "What are role recommendations?",
          answer:
            "Our AI analyzes your skills, experience, and career history to recommend job openings that match your profile. Each recommendation includes a fit score and explains why you're a good match.",
        },
        {
          question: "Can I tailor my resume for specific jobs?",
          answer:
            "Yes! Pro and Business users can use our resume tailoring feature to customize their resume for specific job descriptions. Our AI will suggest modifications to improve your match score.",
        },
        {
          question: "Do you provide interview preparation?",
          answer:
            "Pro and Business users get access to interview preparation tips based on their resume analysis and target roles. This includes common questions and suggested talking points.",
        },
      ],
    },
  ]

  const filteredFAQs = faqCategories
    .map((category) => ({
      ...category,
      faqs: category.faqs.filter(
        (faq) =>
          faq.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
          faq.answer.toLowerCase().includes(searchTerm.toLowerCase()),
      ),
    }))
    .filter((category) => category.faqs.length > 0)

  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className="glass-card border-b border-white/10 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold">JobFit AI</span>
          </Link>
          <div className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-muted-foreground hover:text-foreground transition-colors">
              Home
            </Link>
            <Link href="/pricing" className="text-muted-foreground hover:text-foreground transition-colors">
              Pricing
            </Link>
            <Link href="/dashboard" className="text-muted-foreground hover:text-foreground transition-colors">
              Dashboard
            </Link>
            <ThemeToggle />
            <Button variant="outline" className="glass-button bg-transparent">
              Sign In
            </Button>
            <Button className="bg-blue-600 hover:bg-blue-700">Get Started</Button>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <Badge className="mb-6 bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
            <HelpCircle className="w-4 h-4 mr-1" />
            Frequently Asked Questions
          </Badge>
          <h1 className="text-5xl font-bold mb-6">How can we help you?</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
            Find answers to common questions about JobFit AI, our features, and how to get the most out of our platform.
          </p>

          {/* Search */}
          <div className="max-w-md mx-auto relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
            <Input
              placeholder="Search for answers..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 glass-card"
            />
          </div>
        </div>

        {/* FAQ Categories */}
        <div className="max-w-4xl mx-auto">
          {filteredFAQs.map((category, categoryIndex) => (
            <div key={categoryIndex} className="mb-12">
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                  <category.icon className="w-5 h-5 text-white" />
                </div>
                <h2 className="text-2xl font-bold">{category.title}</h2>
                <Badge className={category.color}>{category.faqs.length} questions</Badge>
              </div>

              <div className="space-y-4">
                {category.faqs.map((faq, faqIndex) => {
                  const globalIndex = categoryIndex * 100 + faqIndex
                  const isOpen = openItems.includes(globalIndex)

                  return (
                    <Card key={faqIndex} className="glass-card">
                      <CardContent className="p-0">
                        <button
                          onClick={() => toggleItem(globalIndex)}
                          className="w-full p-6 text-left flex items-center justify-between hover:bg-white/5 transition-colors"
                        >
                          <h3 className="font-bold text-lg pr-4">{faq.question}</h3>
                          {isOpen ? (
                            <ChevronUp className="w-5 h-5 text-muted-foreground flex-shrink-0" />
                          ) : (
                            <ChevronDown className="w-5 h-5 text-muted-foreground flex-shrink-0" />
                          )}
                        </button>

                        {isOpen && (
                          <div className="px-6 pb-6">
                            <div className="border-t border-white/10 pt-4">
                              <p className="text-muted-foreground leading-relaxed">{faq.answer}</p>
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </div>
          ))}

          {filteredFAQs.length === 0 && searchTerm && (
            <div className="text-center py-12">
              <HelpCircle className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">No results found</h3>
              <p className="text-muted-foreground mb-6">
                We couldn't find any questions matching "{searchTerm}". Try a different search term.
              </p>
              <Button onClick={() => setSearchTerm("")} variant="outline" className="glass-button">
                Clear Search
              </Button>
            </div>
          )}
        </div>

        {/* Contact Support */}
        <div className="mt-20 text-center">
          <Card className="glass-card max-w-2xl mx-auto">
            <CardContent className="p-12">
              <HelpCircle className="w-16 h-16 text-blue-500 mx-auto mb-6" />
              <h2 className="text-3xl font-bold mb-4">Still have questions?</h2>
              <p className="text-muted-foreground mb-8">
                Can't find the answer you're looking for? Our support team is here to help you get the most out of
                JobFit AI.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
                  Contact Support
                </Button>
                <Button size="lg" variant="outline" className="glass-button bg-transparent">
                  Schedule a Demo
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
