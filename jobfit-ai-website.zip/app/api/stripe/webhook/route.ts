import { type NextRequest, NextResponse } from "next/server"
import { StripeService } from "@/lib/stripe"
import { Database } from "@/lib/database"
import { EmailService } from "@/lib/email"
import stripe from "stripe" // Declare the stripe variable

const stripeInstance = stripe(process.env.STRIPE_SECRET_KEY) // Initialize the stripe instance

export async function POST(request: NextRequest) {
  const body = await request.text()
  const signature = request.headers.get("stripe-signature")!

  try {
    const event = await StripeService.constructWebhookEvent(body, signature)

    switch (event.type) {
      case "customer.subscription.created":
      case "customer.subscription.updated": {
        const subscription = event.data.object as any
        const customerId = subscription.customer

        // Get customer details
        const customer = await stripeInstance.customers.retrieve(customerId)

        if (customer && !customer.deleted) {
          // Update user subscription in database
          const user = await Database.getUserByEmail(customer.email!)
          if (user) {
            const planName = subscription.items.data[0].price.nickname || "pro"
            await Database.updateUser(user.id, { subscription: planName })
          }
        }
        break
      }

      case "customer.subscription.deleted": {
        const subscription = event.data.object as any
        const customerId = subscription.customer

        const customer = await stripeInstance.customers.retrieve(customerId)

        if (customer && !customer.deleted) {
          const user = await Database.getUserByEmail(customer.email!)
          if (user) {
            await Database.updateUser(user.id, { subscription: "free" })
          }
        }
        break
      }

      case "invoice.payment_succeeded": {
        const invoice = event.data.object as any

        // Send payment confirmation email
        if (invoice.customer_email) {
          await EmailService.sendEmail({
            to: invoice.customer_email,
            subject: "Payment Confirmation - JobFit AI",
            html: `
              <h2>Payment Confirmed</h2>
              <p>Thank you for your payment of $${(invoice.amount_paid / 100).toFixed(2)}.</p>
              <p>Your subscription is now active!</p>
            `,
          })
        }
        break
      }

      case "invoice.payment_failed": {
        const invoice = event.data.object as any

        // Send payment failed email
        if (invoice.customer_email) {
          await EmailService.sendEmail({
            to: invoice.customer_email,
            subject: "Payment Failed - JobFit AI",
            html: `
              <h2>Payment Failed</h2>
              <p>We were unable to process your payment.</p>
              <p>Please update your payment method to continue using JobFit AI.</p>
            `,
          })
        }
        break
      }
    }

    return NextResponse.json({ received: true })
  } catch (error) {
    console.error("Webhook error:", error)
    return NextResponse.json({ error: "Webhook handler failed" }, { status: 400 })
  }
}
