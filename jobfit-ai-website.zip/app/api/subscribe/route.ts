import { type NextRequest, NextResponse } from "next/server"
import { StripeService, SUBSCRIPTION_PLANS } from "@/lib/stripe"
import { AuthService } from "@/lib/auth"
import stripe from "stripe" // Declare the stripe variable

const stripeInstance = stripe(process.env.STRIPE_SECRET_KEY) // Initialize the stripe instance

export async function POST(request: NextRequest) {
  try {
    const { planId } = await request.json()
    const authHeader = request.headers.get("authorization")
    const token = authHeader?.split(" ")[1]

    if (!token) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 })
    }

    const user = await AuthService.getCurrentUser(token)
    if (!user) {
      return NextResponse.json({ error: "Invalid token" }, { status: 401 })
    }

    const plan = SUBSCRIPTION_PLANS.find((p) => p.id === planId)
    if (!plan || plan.id === "free") {
      return NextResponse.json({ error: "Invalid plan" }, { status: 400 })
    }

    // Create or get Stripe customer
    let customer
    try {
      customer = await StripeService.createCustomer(user.email, user.name)
    } catch (error) {
      // Customer might already exist
      const customers = await stripeInstance.customers.list({ email: user.email })
      customer = customers.data[0]
    }

    // Create subscription
    const subscription = await StripeService.createSubscription(customer.id, plan.stripePriceId)

    return NextResponse.json({
      subscriptionId: subscription.id,
      clientSecret: (subscription.latest_invoice as any)?.payment_intent?.client_secret,
    })
  } catch (error) {
    console.error("Subscription error:", error)
    return NextResponse.json({ error: "Failed to create subscription" }, { status: 500 })
  }
}
