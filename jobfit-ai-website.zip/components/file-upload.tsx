"use client"

import type React from "react"

import { useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Upload, FileText, CheckCircle, AlertCircle, X, Eye, Download } from "lucide-react"

interface FileUploadProps {
  onFileUpload?: (file: File) => void
  maxSize?: number // in MB
  acceptedTypes?: string[]
  multiple?: boolean
}

export function FileUpload({
  onFileUpload,
  maxSize = 10,
  acceptedTypes = [".pdf", ".docx", ".txt", ".md", ".rtf", ".odt"],
  multiple = false,
}: FileUploadProps) {
  const [dragActive, setDragActive] = useState(false)
  const [uploadedFiles, setUploadedFiles] = useState<
    Array<{
      file: File
      progress: number
      status: "uploading" | "success" | "error"
      id: string
    }>
  >([])

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }, [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)

    const files = Array.from(e.dataTransfer.files)
    handleFiles(files)
  }, [])

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    handleFiles(files)
  }

  const handleFiles = async (files: File[]) => {
    for (const file of files) {
      // Validate file type
      const fileExtension = "." + file.name.split(".").pop()?.toLowerCase()
      if (!acceptedTypes.includes(fileExtension)) {
        alert(`File type ${fileExtension} is not supported. Please upload: ${acceptedTypes.join(", ")}`)
        continue
      }

      // Validate file size
      if (file.size > maxSize * 1024 * 1024) {
        alert(`File size exceeds ${maxSize}MB limit`)
        continue
      }

      const fileId = Date.now().toString() + Math.random().toString(36).substr(2, 9)

      // Add file to upload queue
      setUploadedFiles((prev) => [
        ...prev,
        {
          file,
          progress: 0,
          status: "uploading",
          id: fileId,
        },
      ])

      // Simulate file upload with progress
      await simulateUpload(fileId, file)
    }
  }

  const simulateUpload = async (fileId: string, file: File) => {
    try {
      // Simulate upload progress
      for (let progress = 0; progress <= 100; progress += 10) {
        await new Promise((resolve) => setTimeout(resolve, 100))
        setUploadedFiles((prev) => prev.map((f) => (f.id === fileId ? { ...f, progress } : f)))
      }

      // Mark as success
      setUploadedFiles((prev) => prev.map((f) => (f.id === fileId ? { ...f, status: "success" } : f)))

      // Call callback if provided
      if (onFileUpload) {
        onFileUpload(file)
      }
    } catch (error) {
      setUploadedFiles((prev) => prev.map((f) => (f.id === fileId ? { ...f, status: "error" } : f)))
    }
  }

  const removeFile = (fileId: string) => {
    setUploadedFiles((prev) => prev.filter((f) => f.id !== fileId))
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  return (
    <div className="space-y-4">
      {/* Upload Area */}
      <Card
        className={`glass-card border-2 border-dashed transition-colors cursor-pointer ${
          dragActive
            ? "border-blue-500 bg-blue-50/50 dark:bg-blue-950/50"
            : "border-gray-300 dark:border-gray-700 hover:border-blue-400"
        }`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        onClick={() => document.getElementById("file-upload-input")?.click()}
      >
        <CardContent className="p-8 text-center">
          <Upload className={`w-12 h-12 mx-auto mb-4 ${dragActive ? "text-blue-500" : "text-gray-400"}`} />
          <h3 className="text-lg font-semibold mb-2">{dragActive ? "Drop files here" : "Upload your resume"}</h3>
          <p className="text-muted-foreground mb-4">Drag & drop files here, or click to browse</p>
          <div className="flex flex-wrap justify-center gap-2 mb-4">
            {acceptedTypes.map((type) => (
              <Badge key={type} variant="outline" className="text-xs">
                {type.toUpperCase()}
              </Badge>
            ))}
          </div>
          <p className="text-xs text-muted-foreground">Maximum file size: {maxSize}MB</p>
          <input
            id="file-upload-input"
            type="file"
            multiple={multiple}
            accept={acceptedTypes.join(",")}
            onChange={handleFileInput}
            className="hidden"
          />
        </CardContent>
      </Card>

      {/* Uploaded Files */}
      {uploadedFiles.length > 0 && (
        <div className="space-y-3">
          <h4 className="font-medium">Uploaded Files</h4>
          {uploadedFiles.map((fileData) => (
            <Card key={fileData.id} className="glass-card">
              <CardContent className="p-4">
                <div className="flex items-center space-x-4">
                  <div className="flex-shrink-0">
                    <FileText className="w-8 h-8 text-blue-500" />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-2">
                      <p className="text-sm font-medium truncate">{fileData.file.name}</p>
                      <div className="flex items-center space-x-2">
                        {fileData.status === "success" && <CheckCircle className="w-4 h-4 text-green-500" />}
                        {fileData.status === "error" && <AlertCircle className="w-4 h-4 text-red-500" />}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeFile(fileData.id)}
                          className="h-6 w-6 p-0"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
                      <span>{formatFileSize(fileData.file.size)}</span>
                      <span>
                        {fileData.status === "uploading" && `${fileData.progress}%`}
                        {fileData.status === "success" && "Complete"}
                        {fileData.status === "error" && "Failed"}
                      </span>
                    </div>

                    {fileData.status === "uploading" && <Progress value={fileData.progress} className="h-1" />}

                    {fileData.status === "success" && (
                      <div className="flex space-x-2 mt-2">
                        <Button variant="outline" size="sm" className="h-6 text-xs bg-transparent">
                          <Eye className="w-3 h-3 mr-1" />
                          View
                        </Button>
                        <Button variant="outline" size="sm" className="h-6 text-xs bg-transparent">
                          <Download className="w-3 h-3 mr-1" />
                          Download
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
